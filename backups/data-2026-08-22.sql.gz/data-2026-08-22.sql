SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict 6fvXj6z3G27ZaXh9VNp6YpQwMiYrkMVtO3v4GXjkZCBQKhV788fsdRzfZArqXjd

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

INSERT INTO "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") VALUES
	('00000000-0000-0000-0000-000000000000', 'ddada890-2c00-4efe-9311-62d9290989b2', 'authenticated', 'authenticated', 'jomol222@gmail.com', '$2a$10$QihjwXFRmFp2Rc9C7TyMwe41nSvYyRR.4LvDwu9ryiIukMH5naNPW', '2026-08-20 10:49:49.837711+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-21 16:01:16.096367+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-20 10:49:49.794187+00', '2026-08-21 19:20:49.230335+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false),
	('00000000-0000-0000-0000-000000000000', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'authenticated', 'authenticated', 'f.reemasain@gmail.com', '$2a$10$Y8tSHY/vGQpgyPsC1wxgnetTaetOYgg.kofgMQfs5xWgIHqzkPPGy', '2026-08-20 09:57:15.511284+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-21 18:23:03.269656+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-05 19:17:39.551862+00', '2026-08-21 19:30:52.953533+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false),
	('00000000-0000-0000-0000-000000000000', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'authenticated', 'authenticated', 'krishnamithun@gmail.com', '$2a$10$Njtjq0G6GPx6F7iM4dLOyO67JTeFBJRPVNAjX8Kw3tZ1L1AfrNNUG', '2026-08-04 16:09:00.898824+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-05 08:27:04.791075+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-04 16:09:00.888585+00', '2026-08-18 21:13:10.624266+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false),
	('00000000-0000-0000-0000-000000000000', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'authenticated', 'authenticated', 'krishna.mithun@gmail.com', '$2a$10$BiACMjj4Y.fVUg9EzckGWOrRns2FY/GRAfuIczyh9woZdf1Oneo2q', '2026-08-05 09:51:06.489159+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-19 19:01:54.390589+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-05 09:51:06.458017+00', '2026-08-21 19:36:39.470886+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false),
	('00000000-0000-0000-0000-000000000000', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'authenticated', 'authenticated', 'k.rishnamithun@gmail.com', '$2a$10$ijeRhJPSJ85/qvgbNlBy5uZelvrZk27Ir/WA/2YD4Qq80NBbaRM9G', '2026-08-05 20:00:33.081155+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-17 22:18:10.61869+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-05 20:00:33.062824+00', '2026-08-18 21:31:08.535634+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false),
	('00000000-0000-0000-0000-000000000000', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'authenticated', 'authenticated', 'n3lsonv7@gmail.com', '$2a$10$OI2oUHphkRnlZKABmPMIxuFQrEnT1mG/BbPH86dlQQl8.ycO5PcQa', '2026-08-05 19:59:35.397226+00', NULL, '', NULL, '', NULL, '', '', NULL, '2026-08-05 19:23:40.254602+00', '{"provider": "email", "providers": ["email"]}', '{"email_verified": true}', NULL, '2026-08-05 19:21:05.487282+00', '2026-08-05 21:47:23.401703+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

INSERT INTO "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") VALUES
	('64d059d9-0e49-4f9e-89eb-0e5374cce58b', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', '{"sub": "64d059d9-0e49-4f9e-89eb-0e5374cce58b", "email": "krishnamithun@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-08-04 16:09:00.895351+00', '2026-08-04 16:09:00.895399+00', '2026-08-04 16:09:00.895399+00', '0755dbed-12aa-4526-ad23-9c770b3ddc7c'),
	('ebdc54f2-f6fb-4231-a631-d6209f48030e', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '{"sub": "ebdc54f2-f6fb-4231-a631-d6209f48030e", "email": "krishna.mithun@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-08-05 09:51:06.478454+00', '2026-08-05 09:51:06.481781+00', '2026-08-05 09:51:06.481781+00', '2c990f1b-19a5-4e6a-bcb0-1b2389fc5861'),
	('d33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', '{"sub": "d33e1dc6-c6e8-47a7-a134-b13c366bb9b7", "email": "n3lsonv7@gmail.com", "email_verified": true, "phone_verified": false}', 'email', '2026-08-05 19:21:05.501532+00', '2026-08-05 19:21:05.501585+00', '2026-08-05 19:21:05.501585+00', 'e7878ce8-7258-486e-8838-60e6b33eb28a'),
	('0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', '{"sub": "0a0eecb9-a43c-4335-8ca3-a288d5d34e0c", "email": "k.rishnamithun@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-08-05 20:00:33.079349+00', '2026-08-05 20:00:33.079407+00', '2026-08-05 20:00:33.079407+00', 'd7026be8-985b-4db4-8a4c-27a33d3ab112'),
	('0282455d-e03a-48b2-af0b-2e7131c94ceb', '0282455d-e03a-48b2-af0b-2e7131c94ceb', '{"sub": "0282455d-e03a-48b2-af0b-2e7131c94ceb", "email": "f.reemasain@gmail.com", "email_verified": true, "phone_verified": false}', 'email', '2026-08-05 19:17:39.568471+00', '2026-08-05 19:17:39.568524+00', '2026-08-05 19:17:39.568524+00', '257b86bb-6f48-4856-9bd3-301730892351'),
	('ddada890-2c00-4efe-9311-62d9290989b2', 'ddada890-2c00-4efe-9311-62d9290989b2', '{"sub": "ddada890-2c00-4efe-9311-62d9290989b2", "email": "jomol222@gmail.com", "email_verified": false, "phone_verified": false}', 'email', '2026-08-20 10:49:49.834542+00', '2026-08-20 10:49:49.834592+00', '2026-08-20 10:49:49.834592+00', 'a537dc7f-008b-412a-bede-96c421079c7e');


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

INSERT INTO "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") VALUES
	('aff1ef8d-e2bf-49ac-b66f-53417cb26752', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', '2026-08-05 08:00:36.438292+00', '2026-08-05 08:00:36.438292+00', NULL, 'aal1', NULL, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Safari/605.1.15', '149.34.242.95', NULL, NULL, NULL, NULL, NULL),
	('3303736d-244b-4afc-afed-86f8e2e60cbe', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', '2026-08-04 18:39:11.151596+00', '2026-08-05 17:07:51.988517+00', NULL, 'aal1', NULL, '2026-08-05 17:07:51.988431', 'node', '149.34.242.48', NULL, NULL, NULL, NULL, NULL),
	('d4174d88-b4c9-4bd4-aa88-a2d668b66776', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-05 16:59:23.532458+00', '2026-08-05 19:16:27.990233+00', NULL, 'aal1', NULL, '2026-08-05 19:16:27.990103', 'node', '13.40.182.117', NULL, NULL, NULL, NULL, NULL),
	('61a96f5c-3651-4937-8249-77b3f6349d9a', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', '2026-08-05 19:23:40.255457+00', '2026-08-20 20:44:47.412779+00', NULL, 'aal1', NULL, '2026-08-20 20:44:47.412699', 'node', '35.179.135.240', NULL, NULL, NULL, NULL, NULL),
	('ff3bc0e2-1ebc-4211-9abb-5ca1ef74c044', 'ddada890-2c00-4efe-9311-62d9290989b2', '2026-08-20 10:50:23.334099+00', '2026-08-21 16:00:03.211949+00', NULL, 'aal1', NULL, '2026-08-21 16:00:03.211854', 'node', '35.178.88.72', NULL, NULL, NULL, NULL, NULL),
	('585ee2c4-49ec-4b8f-851f-568bb3dc64d9', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-05 19:16:43.212707+00', '2026-08-17 22:15:07.738003+00', NULL, 'aal1', NULL, '2026-08-17 22:15:07.737923', 'node', '3.70.208.111', NULL, NULL, NULL, NULL, NULL),
	('fdadaa92-dffa-4244-86f2-9c52e7712067', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-05 10:16:44.400875+00', '2026-08-17 22:16:23.636887+00', NULL, 'aal1', NULL, '2026-08-17 22:16:23.636819', 'node', '18.170.216.151', NULL, NULL, NULL, NULL, NULL),
	('e407e312-6917-43a8-ad63-9b267958a5e0', 'ddada890-2c00-4efe-9311-62d9290989b2', '2026-08-21 16:01:16.096434+00', '2026-08-21 19:20:49.244107+00', NULL, 'aal1', NULL, '2026-08-21 19:20:49.244012', 'node', '13.40.125.71', NULL, NULL, NULL, NULL, NULL),
	('5544289d-9521-4c0b-8a72-379f635002e2', '0282455d-e03a-48b2-af0b-2e7131c94ceb', '2026-08-21 18:23:03.270405+00', '2026-08-21 19:30:52.968491+00', NULL, 'aal1', NULL, '2026-08-21 19:30:52.968393', 'node', '35.176.24.231', NULL, NULL, NULL, NULL, NULL),
	('e84d0d32-22cc-4237-9702-36d606947d55', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', '2026-08-05 08:27:04.791694+00', '2026-08-18 21:13:10.645703+00', NULL, 'aal1', NULL, '2026-08-18 21:13:10.64556', 'node', '18.175.191.106', NULL, NULL, NULL, NULL, NULL),
	('4d7b6e04-273b-46a4-bf16-dae9fe9e992e', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-17 22:16:49.690758+00', '2026-08-18 21:13:13.112156+00', NULL, 'aal1', NULL, '2026-08-18 21:13:13.112022', 'node', '18.175.191.106', NULL, NULL, NULL, NULL, NULL),
	('f9b659f2-97bf-4395-8ced-bb420b493993', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', '2026-08-17 22:18:10.619461+00', '2026-08-18 21:31:08.536761+00', NULL, 'aal1', NULL, '2026-08-18 21:31:08.536679', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1', '104.28.30.71', NULL, NULL, NULL, NULL, NULL),
	('fcd80106-8fc9-43c3-929b-97be43e09fd6', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-19 19:01:54.391168+00', '2026-08-21 19:36:39.485392+00', NULL, 'aal1', NULL, '2026-08-21 19:36:39.485271', 'node', '35.176.24.231', NULL, NULL, NULL, NULL, NULL),
	('92bfcb6e-1967-490f-bbaa-200031542c06', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-18 21:29:41.598344+00', '2026-08-19 18:21:58.394269+00', NULL, 'aal1', NULL, '2026-08-19 18:21:58.39418', 'node', '13.40.104.251', NULL, NULL, NULL, NULL, NULL),
	('9b968d3f-c118-414c-ae1e-ab84cb767d4e', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', '2026-08-18 21:31:08.612322+00', '2026-08-19 18:43:05.393279+00', NULL, 'aal1', NULL, '2026-08-19 18:43:05.393187', 'node', '13.40.57.160', NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

INSERT INTO "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") VALUES
	('3303736d-244b-4afc-afed-86f8e2e60cbe', '2026-08-04 18:39:11.201291+00', '2026-08-04 18:39:11.201291+00', 'password', '8d9e8c24-bdc0-4d5a-a180-8eb50944c179'),
	('aff1ef8d-e2bf-49ac-b66f-53417cb26752', '2026-08-05 08:00:36.474986+00', '2026-08-05 08:00:36.474986+00', 'password', '692b49ed-8f7a-4510-854e-450d3dcfd62a'),
	('e84d0d32-22cc-4237-9702-36d606947d55', '2026-08-05 08:27:04.807209+00', '2026-08-05 08:27:04.807209+00', 'password', 'cbd5d483-a77b-42d9-bdf1-d47476505d21'),
	('fdadaa92-dffa-4244-86f2-9c52e7712067', '2026-08-05 10:16:44.409837+00', '2026-08-05 10:16:44.409837+00', 'password', '35974f6d-713b-4099-90db-705a084e0f58'),
	('d4174d88-b4c9-4bd4-aa88-a2d668b66776', '2026-08-05 16:59:23.575451+00', '2026-08-05 16:59:23.575451+00', 'password', '2370f631-e32d-4582-a63e-2e0f3c2ecfef'),
	('585ee2c4-49ec-4b8f-851f-568bb3dc64d9', '2026-08-05 19:16:43.229251+00', '2026-08-05 19:16:43.229251+00', 'password', 'c6fa61dc-b84a-4400-b825-fbb247699314'),
	('61a96f5c-3651-4937-8249-77b3f6349d9a', '2026-08-05 19:23:40.278538+00', '2026-08-05 19:23:40.278538+00', 'password', '38dd5883-e251-4ba0-af9b-807cf95311a1'),
	('4d7b6e04-273b-46a4-bf16-dae9fe9e992e', '2026-08-17 22:16:49.714423+00', '2026-08-17 22:16:49.714423+00', 'password', 'ec3e800c-f70c-4781-9545-5f7b3a768fe3'),
	('f9b659f2-97bf-4395-8ced-bb420b493993', '2026-08-17 22:18:10.632022+00', '2026-08-17 22:18:10.632022+00', 'password', '619c1d9f-c84f-401d-94d2-bb8b4ed53604'),
	('92bfcb6e-1967-490f-bbaa-200031542c06', '2026-08-18 21:29:41.622952+00', '2026-08-18 21:29:41.622952+00', 'password', '47b38141-8cda-4053-b53a-9e3f0943dc7c'),
	('9b968d3f-c118-414c-ae1e-ab84cb767d4e', '2026-08-18 21:31:08.614838+00', '2026-08-18 21:31:08.614838+00', 'password', 'c0289128-3bdb-4ef4-8498-f29b2e683a27'),
	('fcd80106-8fc9-43c3-929b-97be43e09fd6', '2026-08-19 19:01:54.432066+00', '2026-08-19 19:01:54.432066+00', 'password', '4e828885-d332-4fb7-806d-a7f5c69234b4'),
	('ff3bc0e2-1ebc-4211-9abb-5ca1ef74c044', '2026-08-20 10:50:23.372225+00', '2026-08-20 10:50:23.372225+00', 'password', '4ee01621-59e0-42f7-98e4-8714d7483482'),
	('e407e312-6917-43a8-ad63-9b267958a5e0', '2026-08-21 16:01:16.112961+00', '2026-08-21 16:01:16.112961+00', 'password', '094f3a2d-aa3b-4a01-a914-338a6b2baec1'),
	('5544289d-9521-4c0b-8a72-379f635002e2', '2026-08-21 18:23:03.351432+00', '2026-08-21 18:23:03.351432+00', 'password', 'b2a44587-f8a5-4ca5-95bf-b69fd8637751');


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

INSERT INTO "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") VALUES
	('00000000-0000-0000-0000-000000000000', 2, '4feqxnifm26i', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-04 18:39:11.178346+00', '2026-08-04 19:56:26.298651+00', NULL, '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 3, 'fhxczz4ih4jk', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-04 19:56:26.316511+00', '2026-08-04 21:58:57.995189+00', '4feqxnifm26i', '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 4, 'rmusks24uru4', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-04 21:58:58.006975+00', '2026-08-04 23:39:08.338823+00', 'fhxczz4ih4jk', '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 5, 'q2caakhuh4wg', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-04 23:39:08.343496+00', '2026-08-05 07:31:51.40975+00', 'rmusks24uru4', '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 7, '22undoym6ddw', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', false, '2026-08-05 08:00:36.464927+00', '2026-08-05 08:00:36.464927+00', NULL, 'aff1ef8d-e2bf-49ac-b66f-53417cb26752'),
	('00000000-0000-0000-0000-000000000000', 10, 'op5dxegqbmal', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-05 10:16:44.405974+00', '2026-08-05 13:14:01.208672+00', NULL, 'fdadaa92-dffa-4244-86f2-9c52e7712067'),
	('00000000-0000-0000-0000-000000000000', 8, 'kppxo5zfbfxb', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-05 08:27:04.800163+00', '2026-08-05 16:03:28.712875+00', NULL, 'e84d0d32-22cc-4237-9702-36d606947d55'),
	('00000000-0000-0000-0000-000000000000', 6, 'ecc6h2g3rgti', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-05 07:31:51.42964+00', '2026-08-05 17:07:51.960196+00', 'q2caakhuh4wg', '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 14, 'irwe4kejtpsb', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', false, '2026-08-05 17:07:51.96674+00', '2026-08-05 17:07:51.96674+00', 'ecc6h2g3rgti', '3303736d-244b-4afc-afed-86f8e2e60cbe'),
	('00000000-0000-0000-0000-000000000000', 13, 'cf4n7qbcapwa', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-05 16:59:23.560323+00', '2026-08-05 19:16:27.948696+00', NULL, 'd4174d88-b4c9-4bd4-aa88-a2d668b66776'),
	('00000000-0000-0000-0000-000000000000', 15, '53v2wbfxou6l', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-05 19:16:27.965205+00', '2026-08-05 19:16:27.965205+00', 'cf4n7qbcapwa', 'd4174d88-b4c9-4bd4-aa88-a2d668b66776'),
	('00000000-0000-0000-0000-000000000000', 17, 'rwrzzayvrrsr', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', true, '2026-08-05 19:23:40.272728+00', '2026-08-05 21:47:23.374856+00', NULL, '61a96f5c-3651-4937-8249-77b3f6349d9a'),
	('00000000-0000-0000-0000-000000000000', 19, 'bqh62wmacvlx', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', false, '2026-08-05 21:47:23.393566+00', '2026-08-05 21:47:23.393566+00', 'rwrzzayvrrsr', '61a96f5c-3651-4937-8249-77b3f6349d9a'),
	('00000000-0000-0000-0000-000000000000', 16, 'ylqmf3mildfe', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-05 19:16:43.220863+00', '2026-08-06 09:44:59.005482+00', NULL, '585ee2c4-49ec-4b8f-851f-568bb3dc64d9'),
	('00000000-0000-0000-0000-000000000000', 20, 'pflcozcnnxjw', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-06 09:44:59.026009+00', '2026-08-07 16:24:23.374397+00', 'ylqmf3mildfe', '585ee2c4-49ec-4b8f-851f-568bb3dc64d9'),
	('00000000-0000-0000-0000-000000000000', 21, '4qnb7ym3rog7', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-07 16:24:23.3902+00', '2026-08-07 18:07:16.242612+00', 'pflcozcnnxjw', '585ee2c4-49ec-4b8f-851f-568bb3dc64d9'),
	('00000000-0000-0000-0000-000000000000', 22, 'qbtm5m6vvafc', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-07 18:07:16.261081+00', '2026-08-08 17:25:35.011804+00', '4qnb7ym3rog7', '585ee2c4-49ec-4b8f-851f-568bb3dc64d9'),
	('00000000-0000-0000-0000-000000000000', 23, 'znhhmfmnhwrq', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-08 17:25:35.031839+00', '2026-08-08 17:25:35.031839+00', 'qbtm5m6vvafc', '585ee2c4-49ec-4b8f-851f-568bb3dc64d9'),
	('00000000-0000-0000-0000-000000000000', 12, 'kiqywhc2mlxk', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-05 16:03:28.732376+00', '2026-08-17 22:16:18.769193+00', 'kppxo5zfbfxb', 'e84d0d32-22cc-4237-9702-36d606947d55'),
	('00000000-0000-0000-0000-000000000000', 11, 'rcei5w2wjlif', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-05 13:14:01.223702+00', '2026-08-17 22:16:23.629538+00', 'op5dxegqbmal', 'fdadaa92-dffa-4244-86f2-9c52e7712067'),
	('00000000-0000-0000-0000-000000000000', 25, 'htjywurdcvhg', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-17 22:16:23.634962+00', '2026-08-17 22:16:23.634962+00', 'rcei5w2wjlif', 'fdadaa92-dffa-4244-86f2-9c52e7712067'),
	('00000000-0000-0000-0000-000000000000', 27, '4t2rnebfd5wr', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', true, '2026-08-17 22:18:10.628484+00', '2026-08-18 16:12:59.968595+00', NULL, 'f9b659f2-97bf-4395-8ced-bb420b493993'),
	('00000000-0000-0000-0000-000000000000', 28, 'rziesydklg3n', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', true, '2026-08-18 16:12:59.982732+00', '2026-08-18 20:32:47.055667+00', '4t2rnebfd5wr', 'f9b659f2-97bf-4395-8ced-bb420b493993'),
	('00000000-0000-0000-0000-000000000000', 24, 'me2xternxsql', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', true, '2026-08-17 22:16:18.785347+00', '2026-08-18 21:13:10.611182+00', 'kiqywhc2mlxk', 'e84d0d32-22cc-4237-9702-36d606947d55'),
	('00000000-0000-0000-0000-000000000000', 30, 'xhbr2ili4i2q', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', false, '2026-08-18 21:13:10.620209+00', '2026-08-18 21:13:10.620209+00', 'me2xternxsql', 'e84d0d32-22cc-4237-9702-36d606947d55'),
	('00000000-0000-0000-0000-000000000000', 26, 'xasc2xi3oswi', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-17 22:16:49.704376+00', '2026-08-18 21:13:13.109775+00', NULL, '4d7b6e04-273b-46a4-bf16-dae9fe9e992e'),
	('00000000-0000-0000-0000-000000000000', 31, 'v4gredvne63d', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-18 21:13:13.110197+00', '2026-08-18 21:13:13.110197+00', 'xasc2xi3oswi', '4d7b6e04-273b-46a4-bf16-dae9fe9e992e'),
	('00000000-0000-0000-0000-000000000000', 29, '22mutfejrk6y', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', true, '2026-08-18 20:32:47.071621+00', '2026-08-18 21:31:08.53286+00', 'rziesydklg3n', 'f9b659f2-97bf-4395-8ced-bb420b493993'),
	('00000000-0000-0000-0000-000000000000', 33, 'gbelv5dtzmur', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', false, '2026-08-18 21:31:08.534673+00', '2026-08-18 21:31:08.534673+00', '22mutfejrk6y', 'f9b659f2-97bf-4395-8ced-bb420b493993'),
	('00000000-0000-0000-0000-000000000000', 32, 'j6ma4acuzioi', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-18 21:29:41.613172+00', '2026-08-19 12:03:53.317449+00', NULL, '92bfcb6e-1967-490f-bbaa-200031542c06'),
	('00000000-0000-0000-0000-000000000000', 35, 'boupinr5vkjq', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-19 12:03:53.337962+00', '2026-08-19 18:21:58.350982+00', 'j6ma4acuzioi', '92bfcb6e-1967-490f-bbaa-200031542c06'),
	('00000000-0000-0000-0000-000000000000', 36, 'r2g7dllce5jx', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-19 18:21:58.367542+00', '2026-08-19 18:21:58.367542+00', 'boupinr5vkjq', '92bfcb6e-1967-490f-bbaa-200031542c06'),
	('00000000-0000-0000-0000-000000000000', 34, '24j64bm7a7ic', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-18 21:31:08.613371+00', '2026-08-19 18:43:05.363243+00', NULL, '9b968d3f-c118-414c-ae1e-ab84cb767d4e'),
	('00000000-0000-0000-0000-000000000000', 37, 'h46wzixzoqca', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-19 18:43:05.374806+00', '2026-08-19 18:43:05.374806+00', '24j64bm7a7ic', '9b968d3f-c118-414c-ae1e-ab84cb767d4e'),
	('00000000-0000-0000-0000-000000000000', 38, 'tfchbjffdxjq', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-19 19:01:54.413661+00', '2026-08-19 21:23:29.472329+00', NULL, 'fcd80106-8fc9-43c3-929b-97be43e09fd6'),
	('00000000-0000-0000-0000-000000000000', 39, 'znhnm24npqnz', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-19 21:23:29.487217+00', '2026-08-20 09:05:21.678094+00', 'tfchbjffdxjq', 'fcd80106-8fc9-43c3-929b-97be43e09fd6'),
	('00000000-0000-0000-0000-000000000000', 40, 'u4qtdocnalwb', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-20 09:05:21.701842+00', '2026-08-20 10:10:22.030342+00', 'znhnm24npqnz', 'fcd80106-8fc9-43c3-929b-97be43e09fd6'),
	('00000000-0000-0000-0000-000000000000', 42, 'b5gxrch5onmb', 'ddada890-2c00-4efe-9311-62d9290989b2', true, '2026-08-20 10:50:23.356876+00', '2026-08-20 19:48:36.603177+00', NULL, 'ff3bc0e2-1ebc-4211-9abb-5ca1ef74c044'),
	('00000000-0000-0000-0000-000000000000', 43, 'ylefs6bb5w3p', 'ddada890-2c00-4efe-9311-62d9290989b2', true, '2026-08-20 19:48:36.62439+00', '2026-08-21 16:00:03.163531+00', 'b5gxrch5onmb', 'ff3bc0e2-1ebc-4211-9abb-5ca1ef74c044'),
	('00000000-0000-0000-0000-000000000000', 44, '4mbag6ulnij2', 'ddada890-2c00-4efe-9311-62d9290989b2', false, '2026-08-21 16:00:03.185613+00', '2026-08-21 16:00:03.185613+00', 'ylefs6bb5w3p', 'ff3bc0e2-1ebc-4211-9abb-5ca1ef74c044'),
	('00000000-0000-0000-0000-000000000000', 45, 'vlpa4uqtzoi2', 'ddada890-2c00-4efe-9311-62d9290989b2', true, '2026-08-21 16:01:16.107919+00', '2026-08-21 19:20:49.216037+00', NULL, 'e407e312-6917-43a8-ad63-9b267958a5e0'),
	('00000000-0000-0000-0000-000000000000', 47, 'vmddnc7apygr', 'ddada890-2c00-4efe-9311-62d9290989b2', false, '2026-08-21 19:20:49.225796+00', '2026-08-21 19:20:49.225796+00', 'vlpa4uqtzoi2', 'e407e312-6917-43a8-ad63-9b267958a5e0'),
	('00000000-0000-0000-0000-000000000000', 46, 'asckbg7j242a', '0282455d-e03a-48b2-af0b-2e7131c94ceb', true, '2026-08-21 18:23:03.317004+00', '2026-08-21 19:30:52.945338+00', NULL, '5544289d-9521-4c0b-8a72-379f635002e2'),
	('00000000-0000-0000-0000-000000000000', 48, 'dsqf6gl7nc6z', '0282455d-e03a-48b2-af0b-2e7131c94ceb', false, '2026-08-21 19:30:52.952113+00', '2026-08-21 19:30:52.952113+00', 'asckbg7j242a', '5544289d-9521-4c0b-8a72-379f635002e2'),
	('00000000-0000-0000-0000-000000000000', 41, 'd7wup7hlffd4', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', true, '2026-08-20 10:10:22.039051+00', '2026-08-21 19:36:39.458605+00', 'u4qtdocnalwb', 'fcd80106-8fc9-43c3-929b-97be43e09fd6'),
	('00000000-0000-0000-0000-000000000000', 49, 'pg3sngnu553v', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', false, '2026-08-21 19:36:39.46563+00', '2026-08-21 19:36:39.46563+00', 'd7wup7hlffd4', 'fcd80106-8fc9-43c3-929b-97be43e09fd6');


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--



--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."profiles" ("id", "email", "org_name", "role", "status", "max_events", "max_contestants", "max_judges", "admin_access_until", "deleted_at", "created_at", "access", "max_active_events", "backup_email") VALUES
	('ebdc54f2-f6fb-4231-a631-d6209f48030e', 'krishna.mithun@gmail.com', NULL, 'owner', 'active', 1, 30, 5, NULL, NULL, '2026-08-05 09:51:06.456494+00', 'full', 1, NULL),
	('64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'krishnamithun@gmail.com', NULL, 'customer', 'deleted', 1, 30, 5, NULL, '2026-08-05 10:17:03.598+00', '2026-08-04 16:09:00.888245+00', 'disabled', 1, NULL),
	('d33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'n3lsonv7@gmail.com', 'Nammude Ireland', 'customer', 'deleted', 1, 30, 3, NULL, '2026-08-17 22:17:28.387+00', '2026-08-05 19:21:05.485857+00', 'disabled', 1, NULL),
	('0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'k.rishnamithun@gmail.com', 'test', 'customer', 'deleted', 1, 30, 2, NULL, '2026-08-19 19:05:10.703+00', '2026-08-05 20:00:33.062483+00', 'disabled', 1, NULL),
	('0282455d-e03a-48b2-af0b-2e7131c94ceb', 'f.reemasain@gmail.com', 'Rejuvenate', 'customer', 'active', 1, 30, 3, NULL, NULL, '2026-08-05 19:17:39.551573+00', 'full', 1, NULL),
	('ddada890-2c00-4efe-9311-62d9290989b2', 'jomol222@gmail.com', 'Adora', 'customer', 'active', 1, 30, 5, NULL, NULL, '2026-08-20 10:49:49.792807+00', 'full', 3, NULL);


--
-- Data for Name: acceptances; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."acceptances" ("id", "profile_id", "document", "version", "accepted_at") VALUES
	('8082375a-f322-47dd-81e7-e5c6e11dbe80', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'terms', '1.0', '2026-08-05 08:10:16.696031+00'),
	('706dea5c-92f9-43b5-bbd9-c3d1f1e36bcd', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'age', '1.0', '2026-08-05 08:10:16.696031+00'),
	('51a2c05c-121d-41d5-9d35-77527905f322', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'consent', '1.0', '2026-08-05 08:10:16.696031+00'),
	('062657ac-b45e-445f-a463-9fe245a40c8a', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'terms', '1.0', '2026-08-05 10:12:04.744251+00'),
	('c3040d85-df54-41f0-8bc9-1727b83e4498', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'age', '1.0', '2026-08-05 10:12:04.744251+00'),
	('d3843a52-7aff-4b1b-9741-25bb64783847', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'consent', '1.0', '2026-08-05 10:12:04.744251+00'),
	('b46d3b29-79cc-489d-8760-01bc5629c35d', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'terms', '1.0', '2026-08-05 19:23:56.212051+00'),
	('6bdd934d-ca99-4c43-8edc-6a03125a4e30', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'age', '1.0', '2026-08-05 19:23:56.212051+00'),
	('ae158fda-2878-4ca6-a7a5-1866ed6500e8', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'consent', '1.0', '2026-08-05 19:23:56.212051+00'),
	('523ebb4b-cf18-4042-9d0c-02c5d2a4543b', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'terms', '1.0', '2026-08-05 20:01:53.003428+00'),
	('c2ca829b-d682-4c35-9288-6bbbe53c1f06', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'age', '1.0', '2026-08-05 20:01:53.003428+00'),
	('3f6d31da-6319-45d5-bd43-c0f80cd87c69', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'consent', '1.0', '2026-08-05 20:01:53.003428+00'),
	('252b92a7-e5da-4e57-af7f-9ad16cd69340', 'ddada890-2c00-4efe-9311-62d9290989b2', 'terms', '1.0', '2026-08-20 10:50:28.633559+00'),
	('b2270a13-68a9-4943-a8d5-f77cbdd09db1', 'ddada890-2c00-4efe-9311-62d9290989b2', 'age', '1.0', '2026-08-20 10:50:28.633559+00'),
	('e62c2a8f-0163-4c4f-bbc6-88a1a069a51d', 'ddada890-2c00-4efe-9311-62d9290989b2', 'consent', '1.0', '2026-08-20 10:50:28.633559+00'),
	('bcb5b445-ebb3-4f00-bb1e-65dc8ab047e5', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'terms', '1.0', '2026-08-21 18:23:09.875982+00'),
	('0d076e45-ef4b-4330-a16d-2bbe6c5a0187', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'age', '1.0', '2026-08-21 18:23:09.875982+00'),
	('0ec12644-01a4-4934-9763-b839a8b55f38', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'consent', '1.0', '2026-08-21 18:23:09.875982+00');


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."audit_log" ("id", "actor_id", "action", "target_type", "target_id", "detail", "created_at") VALUES
	('4a3bc285-a5de-471b-9d46-d4e9f4130d4a', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'event.deleted', 'event', 'c637034c-1637-42ac-a29b-5a7536c612a7', '{"name": "test1", "photos_removed": 0}', '2026-08-05 08:25:20.958539+00'),
	('8251c2fa-4bda-4c1e-bc2a-e363bb690a1f', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', 'password.reset_by_owner', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', NULL, '2026-08-05 13:14:23.932033+00'),
	('482f82f3-1455-4f8d-b1c7-790e1ef42808', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'password.reset_by_owner', 'profile', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', NULL, '2026-08-17 22:17:39.088073+00'),
	('2792ecd9-5a37-49bf-be3a-4ecde46321a1', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'event.deleted', 'event', '42f3b997-fc35-4c1a-bb76-2e603081a056', '{"name": "Test 1", "photos_removed": 0}', '2026-08-19 19:02:35.232831+00'),
	('051cfaa6-8c60-4025-b306-fd2694789d66', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'event.deleted', 'event', '02adfabe-cfd3-4ba6-825d-6a6e80e1e7a8', '{"name": "Food eating", "photos_removed": 0}', '2026-08-19 19:03:07.633614+00'),
	('02b9f31e-8b41-43e4-996d-39f13cdc5c13', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'event.deleted', 'event', 'c4db4f4c-503c-4302-80f1-1163491fbae5', '{"name": "dssdgdsgsdg", "photos_removed": 0}', '2026-08-19 19:03:26.472927+00'),
	('0c381419-1bb3-4c07-82b6-deabf734406c', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', 'password.reset_by_owner', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', NULL, '2026-08-19 19:04:56.144518+00'),
	('0b9007cb-52dc-47a8-a414-98e8ca04a748', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'password.reset_by_owner', 'profile', '0282455d-e03a-48b2-af0b-2e7131c94ceb', NULL, '2026-08-20 09:57:30.200932+00'),
	('43b0f830-9120-4d20-8c44-f16f0e457975', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', 'password.reset_by_owner', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', NULL, '2026-08-20 10:10:23.637469+00'),
	('3043a7d5-c18a-485a-a531-5ee7087be325', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', 'password.reset_by_owner', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', NULL, '2026-08-20 10:37:39.279738+00'),
	('440c7726-7aec-4261-b921-e41524e8f1d4', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', 'password.reset_by_owner', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', NULL, '2026-08-20 10:46:35.393639+00'),
	('528d804a-93dd-4604-b218-121fbfca064b', 'ebdc54f2-f6fb-4231-a631-d6209f48030e', 'account.purged', 'profile', 'a51405af-ef2f-4f27-90fb-42b8fa9c0f32', '{"email": "jomol222@gmail.com", "events": 0, "photos": 0}', '2026-08-20 10:49:25.623774+00');


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."events" ("id", "owner_id", "name", "event_date", "venue", "logo_url", "theme_color", "status", "scale_type", "blind_mode", "winners_count", "show_final_marks", "public_results", "tiebreak_order", "retention_days", "created_at", "code", "carryover", "show_scores", "locked", "comments_mode", "progression") VALUES
	('6b962e43-4457-433b-8326-cd44642d5579', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'Miss Galway 2026', NULL, 'Scientology', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-04 18:56:09.053239+00', '6B962E', 'reset', true, false, 'optional', 'synchronised'),
	('33791df2-697c-47e5-9ee9-1a2f9f283fce', '64d059d9-0e49-4f9e-89eb-0e5374cce58b', 'Miss Kerala', NULL, 'Scientology', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-05 08:27:23.017061+00', '33791D', 'reset', true, false, 'optional', 'synchronised'),
	('f9f788f4-f4b4-4156-9041-a095a6df7397', 'd33e1dc6-c6e8-47a7-a134-b13c366bb9b7', 'Miss india universe ireland', '2026-08-08', 'Church of scientology ', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-05 19:26:23.206489+00', 'F9F788', 'reset', true, false, 'optional', 'independent'),
	('7ba4b923-b46b-4904-809e-2b552fe1db9c', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'Test2', '2026-08-14', NULL, NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-05 20:02:04.585111+00', '7BA4B9', 'reset', true, false, 'optional', 'synchronised'),
	('f2361a60-04b9-4c22-af5a-57f1b19bcd62', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'Test 1', '2026-08-19', NULL, NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-17 22:18:31.127483+00', 'F2361A', 'reset', true, false, 'optional', 'synchronised'),
	('ca9ec90c-7bb8-47b0-89ad-ed9238663939', '0a0eecb9-a43c-4335-8ca3-a288d5d34e0c', 'mit', '2026-08-29', NULL, NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-17 22:18:53.482731+00', 'CA9EC9', 'reset', true, false, 'optional', 'synchronised'),
	('e8adfac7-4389-4be8-ad29-6c4d307082bd', 'ddada890-2c00-4efe-9311-62d9290989b2', 'Miss India Universe 2026', '2026-09-12', 'Scientology', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-20 10:51:13.00965+00', 'T78PQQ', 'reset', true, false, 'optional', 'synchronised'),
	('0a35c94d-8145-4997-b6b2-75844d0bd3fa', 'ddada890-2c00-4efe-9311-62d9290989b2', 'Miss Kerala 2027', '2026-09-12', 'Scientology Community Centre ', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-21 16:02:22.316255+00', 'CZCKNM', 'reset', true, false, 'optional', 'synchronised'),
	('f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'Miss Rejuvenate ', '2026-08-31', NULL, NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-21 18:35:42.342499+00', 'LYTTMD', 'reset', true, false, 'optional', 'synchronised'),
	('aa2da173-9a4e-4585-9b49-a04025c135b1', '0282455d-e03a-48b2-af0b-2e7131c94ceb', 'Miss Ireland ', '2026-08-31', 'Dublin ', NULL, '#0F6E56', 'draft', 'whole', true, 3, true, false, '["category", "head2head", "judge_vote", "manual"]', 90, '2026-08-21 19:02:32.259707+00', 'H7KNP2', 'reset', true, false, 'optional', 'synchronised');


--
-- Data for Name: rounds; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."rounds" ("id", "event_id", "position", "name", "advance_count", "status", "locked_at", "roster_status", "force_closed") VALUES
	('03f75bbf-75c6-491d-81a1-e2f190a72378', '6b962e43-4457-433b-8326-cd44642d5579', 1, 'Wedding Saree Round', 16, 'pending', NULL, 'provisional', false),
	('00790ccf-68cd-43ff-9c7c-8cb5ec72b27e', '6b962e43-4457-433b-8326-cd44642d5579', 2, 'Beach Wear Round', 5, 'pending', NULL, 'provisional', false),
	('032184a9-f0f5-4386-bde6-07ee645d7bba', '6b962e43-4457-433b-8326-cd44642d5579', 3, 'Cockatil Round', NULL, 'pending', NULL, 'provisional', false),
	('e8588219-a838-47d8-9a02-604d9d543f72', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 1, 'round1', 15, 'pending', NULL, 'provisional', false),
	('46313cee-0db2-410e-b9f2-deb26c54a2b9', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 2, 'round2', 5, 'pending', NULL, 'provisional', false),
	('814eb278-a033-4617-9fc8-92c309c25d9b', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 3, 'round3', NULL, 'pending', NULL, 'provisional', false),
	('0095884a-aff2-4dc9-89fb-5c71085da505', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 1, 'Bridal ', 8, 'pending', NULL, 'provisional', false),
	('f97a862a-3739-437d-afc2-1b64f3ca52a3', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 2, 'Beach', 5, 'pending', NULL, 'provisional', false),
	('739ef68c-3627-4788-a406-556e6cbbe8f1', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 3, 'Evening', 5, 'pending', NULL, 'provisional', false),
	('df89e28e-3825-4999-a661-67fb3c737052', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 4, 'Bsbbd', NULL, 'pending', NULL, 'provisional', false),
	('e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '7ba4b923-b46b-4904-809e-2b552fe1db9c', 1, 'Round 1', 6, 'pending', NULL, 'provisional', true),
	('0a138b95-9642-48fd-8a6d-ed0810638b5a', '7ba4b923-b46b-4904-809e-2b552fe1db9c', 2, 'round 2', 5, 'pending', NULL, 'provisional', true),
	('44b24dc3-0cea-482b-a666-943701ffa25d', '7ba4b923-b46b-4904-809e-2b552fe1db9c', 3, 'round 3', NULL, 'pending', NULL, 'provisional', true),
	('3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', 1, 'round 1', 7, 'pending', NULL, 'provisional', false),
	('6efcabad-bfce-42c7-b503-b4887880c474', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', 2, 'round 2', 5, 'pending', NULL, 'provisional', false),
	('69490190-ffbd-4b86-b99a-f58b077e00e0', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', 3, 'round 3', NULL, 'pending', NULL, 'provisional', false),
	('4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', 1, 'Traditional Round', 7, 'pending', NULL, 'provisional', false),
	('59e073c7-5bb6-4fc9-a963-716f140426f9', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', 2, 'Beach Round', 5, 'pending', NULL, 'provisional', false),
	('2d915dd9-4476-473b-951a-e7308a01bc80', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', 3, 'Evening Gown', NULL, 'pending', NULL, 'provisional', false),
	('cafb8481-681a-44d1-bc71-f5ffeccdac6a', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', 1, 'Traditional Innovation ', 7, 'pending', NULL, 'provisional', false),
	('9fec09c1-1849-4508-be55-e604dbf087c2', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', 2, 'Cocktail Round', 5, 'pending', NULL, 'provisional', false),
	('c3a87435-e70e-45fd-83e0-c75e0831dfcb', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', 3, 'Gown Round', NULL, 'pending', NULL, 'provisional', false),
	('7542144c-c1ef-40ae-9fcf-160ddab4660f', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', 1, 'Round 1', 2, 'pending', NULL, 'provisional', false),
	('62677e14-1364-463d-bbf4-ffe90731a55b', 'aa2da173-9a4e-4585-9b49-a04025c135b1', 1, 'Round 1', 7, 'pending', NULL, 'provisional', false),
	('a49fc10c-0006-4f85-9319-de52b14d00f2', 'aa2da173-9a4e-4585-9b49-a04025c135b1', 2, 'Round 2', 5, 'pending', NULL, 'provisional', false),
	('8466353c-ad30-45bb-ace6-f8c06d73763d', 'aa2da173-9a4e-4585-9b49-a04025c135b1', 3, 'Round 3', NULL, 'pending', NULL, 'provisional', false);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."categories" ("id", "round_id", "position", "name", "max_score", "weight", "tiebreak_priority") VALUES
	('39b09cad-414c-45c4-aca3-3356a03a4dd0', 'e8588219-a838-47d8-9a02-604d9d543f72', 1, 'c1', 10, 1, NULL),
	('1fbbdde6-2858-453b-8b1d-bec46b2fc4aa', 'e8588219-a838-47d8-9a02-604d9d543f72', 2, 'c2', 10, 1, NULL),
	('a3bdcdbb-542c-402f-9ef2-1e7404981b10', 'e8588219-a838-47d8-9a02-604d9d543f72', 3, 'c3', 10, 1, NULL),
	('1ef96fd7-4bdb-474b-81ec-4989d7762f3e', 'e8588219-a838-47d8-9a02-604d9d543f72', 4, 'c4', 10, 1, NULL),
	('3129e039-d0ce-4496-8024-1d1cd4941333', 'e8588219-a838-47d8-9a02-604d9d543f72', 5, 'c5', 10, 1, NULL),
	('b389fcdd-c11b-44bf-94cb-9e38d1d63224', '46313cee-0db2-410e-b9f2-deb26c54a2b9', 1, 'c1', 10, 1, NULL),
	('ec3744f8-6620-4790-8207-e1bc2037a035', '46313cee-0db2-410e-b9f2-deb26c54a2b9', 2, 'c2', 10, 1, NULL),
	('aa2a1011-7563-4b94-b230-dd90bcec5ab0', '46313cee-0db2-410e-b9f2-deb26c54a2b9', 3, 'c3', 10, 1, NULL),
	('7a83b379-e92b-4acd-b890-c479c05f5fe7', '46313cee-0db2-410e-b9f2-deb26c54a2b9', 4, 'c4', 10, 1, NULL),
	('8ee00c69-90e5-496e-9523-b4f650383c40', '46313cee-0db2-410e-b9f2-deb26c54a2b9', 5, 'c5', 10, 1, NULL),
	('69e711c6-80eb-4ac7-a148-2b52fc81d62c', '814eb278-a033-4617-9fc8-92c309c25d9b', 1, 'Question1', 10, 1, NULL),
	('de79be5e-1403-41e4-853c-105ee18d6665', '814eb278-a033-4617-9fc8-92c309c25d9b', 2, 'q2', 10, 1, NULL),
	('b76db7f5-4c8a-455e-90a5-d00e59c7cb51', '814eb278-a033-4617-9fc8-92c309c25d9b', 3, 'q3', 10, 1, NULL),
	('9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', '0095884a-aff2-4dc9-89fb-5c71085da505', 1, '1', 10, 1, NULL),
	('941752fa-f63f-4d9e-b428-22c7519385b1', '0095884a-aff2-4dc9-89fb-5c71085da505', 2, 'Smile', 10, 1, NULL),
	('851c526d-ea44-4807-9fd0-5dcad8b722c8', '0095884a-aff2-4dc9-89fb-5c71085da505', 3, 'Skin', 10, 1, NULL),
	('0c7bff5a-e219-4971-b01e-5e927adcb4ca', 'f97a862a-3739-437d-afc2-1b64f3ca52a3', 1, 'Hdhhd', 10, 1, NULL),
	('4d287aa2-497d-4903-ba4b-e16f320e2790', 'f97a862a-3739-437d-afc2-1b64f3ca52a3', 2, 'Hhdjjd', 10, 1, NULL),
	('b6771750-c66b-44c4-8724-35ac2ee03710', 'f97a862a-3739-437d-afc2-1b64f3ca52a3', 3, 'Dbbdhd', 10, 1, NULL),
	('586ff053-ea8e-4243-a96e-6b24e968b4ac', '739ef68c-3627-4788-a406-556e6cbbe8f1', 2, 'Ndbhd', 10, 1, NULL),
	('5a9e3ae2-761b-4c08-8e67-c0c88f9c6324', '739ef68c-3627-4788-a406-556e6cbbe8f1', 3, 'Hhdhr', 10, 1, NULL),
	('ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 1, 'hdbbsb', 10, 1, NULL),
	('005ab4d2-5aaa-4477-92fd-350956ba965e', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 2, 'dbhdj', 10, 1, NULL),
	('94fddb8a-a274-4c2b-b6f6-6776a06a9379', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 3, 'bdbbs', 10, 1, NULL),
	('9c516fb7-9e36-4283-90e0-987d68050676', '0a138b95-9642-48fd-8a6d-ed0810638b5a', 1, 'dbdh', 10, 1, NULL),
	('4afba076-6c0d-4f34-baf3-8a19a714b8d1', '0a138b95-9642-48fd-8a6d-ed0810638b5a', 2, 'hdbbs', 10, 1, NULL),
	('431338e5-ad04-40be-8954-57d2ad3481f6', '0a138b95-9642-48fd-8a6d-ed0810638b5a', 3, 'dhhdh', 10, 1, NULL),
	('efda0631-b085-44a7-b0e1-1ae7e409fd44', '44b24dc3-0cea-482b-a666-943701ffa25d', 1, 'ndbbsb', 10, 1, NULL),
	('0fbf97a7-c0c0-41a3-8993-8e42c789ad13', '44b24dc3-0cea-482b-a666-943701ffa25d', 2, 'hdbbsb', 10, 1, NULL),
	('44cf679c-61fb-42a6-9b2e-b2b01058c494', '44b24dc3-0cea-482b-a666-943701ffa25d', 3, 'dbbdhs', 10, 1, NULL),
	('ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 1, 'look1', 10, 1, NULL),
	('75540c6d-d58f-4329-8fc4-81fc05175a3d', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 2, 'look2', 10, 1, NULL),
	('02380567-59bc-41f2-8130-5f231282e1c9', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 3, 'look3', 10, 1, NULL),
	('f595a7a0-b290-46f8-aa5d-7d8cb7f2baca', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 4, 'look4', 10, 1, NULL),
	('cf72aec0-3018-4f96-a634-db1c6c750aa7', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 5, 'look5', 10, 1, NULL),
	('17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', '6efcabad-bfce-42c7-b503-b4887880c474', 1, 'book1', 10, 1, NULL),
	('4afb9541-1025-4487-b06f-0e4601e53364', '6efcabad-bfce-42c7-b503-b4887880c474', 2, 'book2', 10, 1, NULL),
	('9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', '6efcabad-bfce-42c7-b503-b4887880c474', 3, 'book3', 10, 1, NULL),
	('3ed4df0c-a0f2-46d7-b9c2-3e6ed9b0dbb6', '69490190-ffbd-4b86-b99a-f58b077e00e0', 1, 'took1', 10, 1, NULL),
	('94410e30-1354-40f0-9796-a40e166a354d', '69490190-ffbd-4b86-b99a-f58b077e00e0', 2, 'took2', 10, 1, NULL),
	('3987eea4-ee46-45f6-8ea7-42bbdc5838d5', '69490190-ffbd-4b86-b99a-f58b077e00e0', 3, 'took3', 10, 1, NULL),
	('5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 1, 'Styling and Outfit', 30, 1, NULL),
	('50836093-8e4d-4ca5-8e01-6c880723c764', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 2, 'Introduction', 10, 1, NULL),
	('f33bd341-1df5-4e60-abf7-9eb02c4efd0d', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 3, 'Walk', 10, 1, NULL),
	('9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', '59e073c7-5bb6-4fc9-a963-716f140426f9', 1, 'Styling & Outfit', 30, 1, NULL),
	('b131832a-4d70-406b-9da9-d04f63836f8b', '59e073c7-5bb6-4fc9-a963-716f140426f9', 2, 'Q&A', 20, 1, NULL),
	('6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', '2d915dd9-4476-473b-951a-e7308a01bc80', 1, 'Q&A', 40, 1, NULL),
	('6c4efdcb-f3b1-4146-b9c8-49862dcfa840', '2d915dd9-4476-473b-951a-e7308a01bc80', 2, 'Outfit', 10, 1, NULL),
	('01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 1, 'Outfit & Styling', 20, 1, NULL),
	('a92157f6-3202-4c19-8732-908cdb7ec18e', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 2, 'Innovation', 20, 1, NULL),
	('fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 3, 'Introduction', 10, 1, NULL),
	('47118210-7d94-4b25-9364-a423e229fdea', '9fec09c1-1849-4508-be55-e604dbf087c2', 1, 'Q&A', 20, 1, NULL),
	('446a0235-2339-4acb-bcdb-a7255b44a6be', '9fec09c1-1849-4508-be55-e604dbf087c2', 2, 'styling', 10, 1, NULL),
	('95f5faad-fabd-43af-a9f5-53849390a0bd', '9fec09c1-1849-4508-be55-e604dbf087c2', 3, 'walk', 10, 1, NULL),
	('41eb54ef-a3a4-471e-9b5c-3b557883e83a', '9fec09c1-1849-4508-be55-e604dbf087c2', 4, 'outfit', 10, 1, NULL),
	('ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', 1, 'Q&A', 30, 1, NULL),
	('369eb3a9-25bd-4e00-abe5-6d940e10e653', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', 2, 'Outfit', 20, 1, NULL),
	('5fb86f5d-0cb9-44cd-b964-a82eca07b485', '62677e14-1364-463d-bbf4-ffe90731a55b', 1, 'Sfgrv', 10, 1, NULL),
	('e722765b-7e22-4099-a0d3-5f5514d5a297', '62677e14-1364-463d-bbf4-ffe90731a55b', 2, 'Poing', 10, 1, NULL),
	('78542b2b-d2dc-4371-85cf-f7d6d209fbcb', '62677e14-1364-463d-bbf4-ffe90731a55b', 3, ' Cvbfg', 10, 1, NULL),
	('d5071420-340c-45a0-a783-512e96222e4b', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 1, 'Bffgb', 10, 1, NULL),
	('ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 2, 'The v', 10, 1, NULL),
	('fd541560-8cb0-47a2-8785-c379fffe7c44', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 3, 'The. Blm', 10, 1, NULL),
	('9fa5c309-c34d-484f-9854-15ad34121f46', '8466353c-ad30-45bb-ace6-f8c06d73763d', 1, 'Have bbb', 10, 1, NULL),
	('e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', '8466353c-ad30-45bb-ace6-f8c06d73763d', 2, 'Vffgb', 10, 1, NULL);


--
-- Data for Name: contestants; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."contestants" ("id", "event_id", "bib_number", "name", "description", "photo_url", "status") VALUES
	('07ef2cd6-042a-4cf1-bec7-0a6e425f7a44', '6b962e43-4457-433b-8326-cd44642d5579', '1', 'dssdfg', NULL, NULL, 'active'),
	('a04f7886-4ec9-4e1b-a0fa-1c71db9ab404', '6b962e43-4457-433b-8326-cd44642d5579', '2', 'efwefwed', NULL, NULL, 'active'),
	('67de6247-c29b-4c12-8693-9155a13b4018', '6b962e43-4457-433b-8326-cd44642d5579', '3', 'ewgwegwg', NULL, NULL, 'active'),
	('178c9382-d67a-49ec-9197-b1797ec05d4f', '6b962e43-4457-433b-8326-cd44642d5579', '4', 'ewgwegwgvwe', NULL, NULL, 'active'),
	('cfccfaa7-2687-41d1-bee1-1ee7db7e9477', '6b962e43-4457-433b-8326-cd44642d5579', '5', 'ewewfew', NULL, NULL, 'active'),
	('09c35bfd-1a81-4bbc-9240-b5befe8b2d45', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '1', 'a', NULL, NULL, 'active'),
	('04f1cf64-e45c-438c-baa5-5262b2f5af29', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '2', 'b', NULL, NULL, 'active'),
	('ef95c5df-3756-42a0-8b94-865b95e7cedf', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '3', 'c', NULL, NULL, 'active'),
	('bab3cf7d-ae5b-4b6e-ab2b-0d87ef84ccda', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '4', 'd', NULL, NULL, 'active'),
	('1f9015c2-c1f5-4d0a-a9ba-b14b9c8ebe9b', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '5', 'e', NULL, NULL, 'active'),
	('c472cbcc-7f22-44a5-900e-f1cf82119a0e', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '6', 'f', NULL, NULL, 'active'),
	('89b1ef49-78ed-47d1-b04f-4dfbe55bde60', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '7', 'g', NULL, NULL, 'active'),
	('2745ea87-26f5-44d2-b220-5d59499fc06f', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '8', 'h', NULL, NULL, 'active'),
	('78f430f2-a8d3-4217-a2c6-3e96d7be94fa', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '9', 'I', NULL, NULL, 'active'),
	('b27bd2a9-1c66-4e0d-8bcc-84f2ddf72dad', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '10', 'j', NULL, NULL, 'active'),
	('e38183bb-f6aa-4a5e-a124-d9798f1a7434', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '11', 'k', NULL, NULL, 'active'),
	('c32fc8c5-4e03-4c78-aeae-3942e3787a2a', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '12', 'l', NULL, NULL, 'active'),
	('92a7b6a6-cd63-4948-ac56-582de03615be', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '13', 'm', NULL, NULL, 'active'),
	('fe33527a-ee17-4937-b924-4cd341a14a8e', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '14', 'n', NULL, NULL, 'active'),
	('725d8ce5-8c36-45fb-b345-0fd0a6a80759', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '15', 'o', NULL, NULL, 'active'),
	('fc3c258d-0a9b-4878-9123-6ad4a1213441', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '16', 'p', NULL, NULL, 'active'),
	('c0311456-e245-4aaa-ab00-3c1b5da7fe25', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '17', 'q', NULL, NULL, 'active'),
	('09479686-6159-42df-a0f9-22f298e73eb4', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '18', 'r', NULL, NULL, 'active'),
	('acf34c25-e926-4342-aa80-d0cc2aecd1a6', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '19', 's', NULL, NULL, 'active'),
	('dd5e318b-40b0-4ad9-ba68-c18f61a7cb46', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '20', 't', NULL, NULL, 'active'),
	('e806181c-f909-4aae-a049-5d45445b8957', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '21', 'u', NULL, NULL, 'active'),
	('86a601f1-a52e-4412-ac1a-153218614595', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '22', 'v', NULL, NULL, 'active'),
	('7eee7a0a-1c34-4f00-9717-26714a0ffe19', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '23', 'w', NULL, NULL, 'active'),
	('5e64c596-77e6-43c5-8fb3-4af6a259bc94', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '24', 'x', NULL, NULL, 'active'),
	('b730c222-9fdb-4bdc-a012-50023369627a', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '25', 'y', NULL, NULL, 'active'),
	('ea50ab0f-d8b5-40ab-9dfb-afc1dc7b587f', '33791df2-697c-47e5-9ee9-1a2f9f283fce', '26', 'z', NULL, NULL, 'active'),
	('1e3c2613-d4f0-4f15-82d8-b849fe4c6a39', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '1', 'Hareena', NULL, NULL, 'active'),
	('90876af7-22de-4de0-b630-5de72e21ce1e', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '2', 'Jo', NULL, NULL, 'active'),
	('26f49b40-9ae0-4595-97b1-7b0791f8ad39', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '3', 'Anu', NULL, NULL, 'active'),
	('37a864ab-37e1-4293-9423-e716aa10c2e2', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '4', 'Bibin', NULL, NULL, 'active'),
	('49837da1-d798-4530-9885-3703cc1915b4', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '5', 'Nelson ', NULL, NULL, 'active'),
	('7dbddbe8-b456-4835-9d37-75100599312f', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '6', 'Reema', NULL, NULL, 'active'),
	('40bec97d-cc6b-458c-a17c-9ec488b72779', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '7', 'Luttappi', NULL, NULL, 'active'),
	('f2842092-c824-487f-907a-ac235d50845c', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '8', 'Kuttoosan', NULL, NULL, 'active'),
	('2a904659-aed2-4c7e-ab9a-89cf91757e24', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '9', 'Dakini', NULL, NULL, 'active'),
	('8065ac83-7234-4e53-9bd5-c590fc8623e8', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '10', 'Michael Jackson ', NULL, NULL, 'active'),
	('30f6252e-9b3a-4cf1-be5b-afadb953f733', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '11', 'Dinkan', NULL, NULL, 'active'),
	('ae557237-0744-4d41-bde1-cf6402e3598d', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '12', 'Mayavi', NULL, NULL, 'active'),
	('c5b159e8-6431-4a85-ad94-f88352e5c51f', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '1', 'a', NULL, NULL, 'active'),
	('9c8c46f0-f25c-4c54-baf8-57bc680b0f1c', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '2', 'b', NULL, NULL, 'active'),
	('c76a89cf-db23-423d-aedc-3372c8491b84', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '3', 'c', NULL, NULL, 'active'),
	('8cc0b64d-7752-4346-ab7e-39f17e0bec88', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '4', 'd', NULL, NULL, 'active'),
	('c65792f9-02c8-4be1-84dc-81e5214b1228', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '5', 'e', NULL, NULL, 'active'),
	('7ef0ec07-0491-41ed-98b5-65d069ccb3f1', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '6', 'f', NULL, NULL, 'active'),
	('634cd2a3-8d41-4ed9-8814-bb072e31552d', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '7', 'g', NULL, NULL, 'active'),
	('0b0cfb2c-edba-4d6c-8b28-26b792ce1bb8', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '8', 'h', NULL, NULL, 'active'),
	('9540dd86-4493-4d90-80bb-e8f0a29210a9', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '9', 'i', NULL, NULL, 'active'),
	('3d99342e-b4f0-4d9f-b908-1d91c0b75168', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '10', 'j', NULL, NULL, 'active'),
	('2cb05ecc-dcb6-4c9d-8ebe-36841edbc890', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '1', 'a', NULL, NULL, 'active'),
	('acd773ad-2232-478c-bd52-953790b7ad83', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '2', 'b', NULL, NULL, 'active'),
	('f680afbd-d8d6-4310-9d0a-a398e013e5ab', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '3', 'c', NULL, NULL, 'active'),
	('0b18f949-1172-48d9-99c1-76eb050962c4', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '4', 'd', NULL, NULL, 'active'),
	('6f355d49-dd22-4ffa-9ef1-76ef19d0cc60', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '5', 'e', NULL, NULL, 'active'),
	('3696ac77-81db-46cf-a13f-505907037ac9', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '6', 'f', NULL, NULL, 'active'),
	('89c20c7e-e37b-467c-a816-59a56f2f9aa1', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '7', 'g', NULL, NULL, 'active'),
	('b7077a01-54c8-453c-9e28-2c47be0ba91e', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '8', 'h', NULL, NULL, 'active'),
	('e70cc3e4-54d0-475f-8d0e-ca63f497f53b', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '9', 'i', NULL, NULL, 'active'),
	('82576520-b4f3-4a98-a72d-b4fc84149876', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '10', 'j', NULL, NULL, 'active'),
	('f5ea5698-72a1-4205-ac59-b0f10d4deb50', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '1', 'Shivani', NULL, NULL, 'active'),
	('9cb84904-cac3-4621-8434-5ba3bb37ea90', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '2', 'Nikhitha', NULL, NULL, 'active'),
	('8767afb5-627a-4132-85df-007da2b170dc', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '3', 'Aswathy', NULL, NULL, 'active'),
	('99ad481f-ff0d-43a3-a53d-5880d6437357', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '4', 'Anumol', NULL, NULL, 'active'),
	('db8e313a-02c9-49f4-acf3-185ba95cd531', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '5', 'Tinku', NULL, NULL, 'active'),
	('f1902097-0975-4553-84d0-6681fa6f1d98', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '6', 'Taniya', NULL, NULL, 'active'),
	('dc76d32f-fa20-41c2-9967-d77f764ce21f', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '7', 'Haripriya', NULL, NULL, 'active'),
	('a736b77e-a727-467b-9248-5a7d969dfe0b', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '8', 'Monica', NULL, NULL, 'active'),
	('9254982c-f4be-4a53-84e2-6ffcd7a51c9d', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '9', 'Linu', NULL, NULL, 'active'),
	('38961f9f-d453-4973-9030-78c443882f54', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '10', 'Sophia', NULL, NULL, 'active'),
	('bfe6480f-0a58-4f16-ba23-8db03e94c0f2', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '1', 'Aleesha', NULL, NULL, 'active'),
	('b962ba6a-6f85-4cbb-a4fe-66b9bb521b18', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '2', 'Reema', NULL, NULL, 'active'),
	('2433730c-ba3d-43d2-9c0c-3bab05a17511', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '3', 'Jinu', NULL, NULL, 'active'),
	('6581f59c-7cfe-41c1-ac66-6516d86771e1', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '4', 'Alaina', NULL, NULL, 'active'),
	('61caf17f-8bdd-4b48-9732-268377133d73', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '5', 'Sree', NULL, NULL, 'active'),
	('a7876ac2-5b73-4c72-b83e-43590557b858', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '6', 'Anju', NULL, NULL, 'active'),
	('e49af40c-e9ec-4cc2-af8a-0852fbddb23a', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '7', 'Deni', NULL, NULL, 'active'),
	('d90c24f6-3a84-4d76-8818-a6067f0b7098', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '8', 'Shiny', NULL, NULL, 'active'),
	('8b6306f8-90bd-4705-a8fc-e980e59bdb44', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '10', 'Varsha', NULL, NULL, 'active'),
	('0feb4bd0-bd2e-4156-86b9-4697f9f1def5', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '1', 'A', NULL, NULL, 'active'),
	('5a04954f-9659-49de-9da0-21c83ecc012d', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '2', 'B', NULL, NULL, 'active'),
	('e30fa6a1-7be7-49f9-b2a0-84fc36b8384f', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '3', 'C', NULL, NULL, 'active'),
	('f754af08-f4de-4553-a0e0-a4239cc383e7', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '4', 'D', NULL, NULL, 'active'),
	('a34257bf-796e-44a2-831e-69d57fac0ef3', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '5', 'E', NULL, NULL, 'active'),
	('87c280b1-1edc-4021-8a1f-d6a440e867b3', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '6', 'F', NULL, NULL, 'active'),
	('f88d88d9-0593-482f-9b78-5f97269fca60', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '7', 'G', NULL, NULL, 'active'),
	('50dc6241-4125-43af-91e7-5f3306c8684d', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '8', 'H', NULL, NULL, 'active'),
	('41f03abe-69cf-4faa-895e-9cdacec148e3', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '9', 'I', NULL, NULL, 'active'),
	('29bb0e80-b386-4c35-addf-466216a24287', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', '10', 'J', NULL, NULL, 'active'),
	('47df3718-6b8b-408e-9274-ad3c58d8673d', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '1', '1', NULL, NULL, 'active'),
	('495784cd-65c5-42a5-9eb3-bd4d871c19bf', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '2', '2', NULL, NULL, 'active'),
	('7549b1e0-6341-46fd-b411-08fb2efc73df', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '3', '3', NULL, NULL, 'active'),
	('979ccbd7-87d7-4c55-a569-4eb75c8fd27e', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '4', '4', NULL, NULL, 'active'),
	('bbe408b3-46ae-4806-bf8a-8827f9fbf5ff', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '5', '5', NULL, NULL, 'active'),
	('4d95a96b-2d9e-4372-94ed-400c5cc41422', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '6', '6', NULL, NULL, 'active'),
	('6c58c960-da79-4e00-94eb-c312044a8b46', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '7', '7', NULL, NULL, 'active'),
	('8dbb4799-ccf9-41ce-a499-65cba06bbd58', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '8', '8', NULL, NULL, 'active'),
	('d7742370-22c1-46e3-8692-d18f33580153', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '9', '9', NULL, NULL, 'active'),
	('f89f89cb-3606-4de1-a437-b19ae6a02647', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '10', '10', NULL, NULL, 'active');


--
-- Data for Name: enquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."entries" ("id", "round_id", "contestant_id") VALUES
	('de47c26d-8c00-4f06-a287-cba5239e23be', '03f75bbf-75c6-491d-81a1-e2f190a72378', '07ef2cd6-042a-4cf1-bec7-0a6e425f7a44'),
	('4ec01c56-33c1-4337-8ba0-9c0476bfb055', '03f75bbf-75c6-491d-81a1-e2f190a72378', 'a04f7886-4ec9-4e1b-a0fa-1c71db9ab404'),
	('bed1f7a8-04ce-4edd-93cf-cfd9d85fbf14', '03f75bbf-75c6-491d-81a1-e2f190a72378', '67de6247-c29b-4c12-8693-9155a13b4018'),
	('d0e8619b-3a96-487c-a8cd-ab8a0fcd08ef', '03f75bbf-75c6-491d-81a1-e2f190a72378', '178c9382-d67a-49ec-9197-b1797ec05d4f'),
	('439ce1bc-bd8f-45d7-b976-f96f92d36a40', '03f75bbf-75c6-491d-81a1-e2f190a72378', 'cfccfaa7-2687-41d1-bee1-1ee7db7e9477'),
	('1c2bd9c7-0567-4e6e-8080-3347802fb40a', '0095884a-aff2-4dc9-89fb-5c71085da505', '1e3c2613-d4f0-4f15-82d8-b849fe4c6a39'),
	('7d632118-89b1-4c64-95a9-7f07fba1dac7', '0095884a-aff2-4dc9-89fb-5c71085da505', '90876af7-22de-4de0-b630-5de72e21ce1e'),
	('82178d66-a561-442f-a03a-3dfd132e2c9f', '0095884a-aff2-4dc9-89fb-5c71085da505', '26f49b40-9ae0-4595-97b1-7b0791f8ad39'),
	('18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '0095884a-aff2-4dc9-89fb-5c71085da505', '37a864ab-37e1-4293-9423-e716aa10c2e2'),
	('73961840-95de-4046-8806-b6846e4e3658', '0095884a-aff2-4dc9-89fb-5c71085da505', '49837da1-d798-4530-9885-3703cc1915b4'),
	('6e27131a-252d-422f-a6ee-a1d99338b289', '0095884a-aff2-4dc9-89fb-5c71085da505', '7dbddbe8-b456-4835-9d37-75100599312f'),
	('d6d6da14-e005-44a8-9208-3c5a9b2fa77b', '0095884a-aff2-4dc9-89fb-5c71085da505', '40bec97d-cc6b-458c-a17c-9ec488b72779'),
	('f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '0095884a-aff2-4dc9-89fb-5c71085da505', 'f2842092-c824-487f-907a-ac235d50845c'),
	('d2978b0a-6d76-46dc-bd91-d80cf460235f', '0095884a-aff2-4dc9-89fb-5c71085da505', '2a904659-aed2-4c7e-ab9a-89cf91757e24'),
	('e9ece2ee-293b-4488-a198-622b8d65ded0', '0095884a-aff2-4dc9-89fb-5c71085da505', '8065ac83-7234-4e53-9bd5-c590fc8623e8'),
	('24962bbd-a98a-4818-9d8e-f87145d2c06c', '0095884a-aff2-4dc9-89fb-5c71085da505', '30f6252e-9b3a-4cf1-be5b-afadb953f733'),
	('fa748908-52c0-4825-a2aa-4890c522cbd2', '0095884a-aff2-4dc9-89fb-5c71085da505', 'ae557237-0744-4d41-bde1-cf6402e3598d'),
	('073669c5-5c65-4db8-8b88-96c2547f5f48', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 'c5b159e8-6431-4a85-ad94-f88352e5c51f'),
	('0ae2e4b8-7a52-4b58-9e04-277f1d374265', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '9c8c46f0-f25c-4c54-baf8-57bc680b0f1c'),
	('35632d85-9b61-4a27-80cd-7c1227cfd96e', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 'c76a89cf-db23-423d-aedc-3372c8491b84'),
	('698a04d2-9078-4790-94bf-614fd1a8ba80', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '8cc0b64d-7752-4346-ab7e-39f17e0bec88'),
	('d5ebf7d5-2e63-4baf-ad3c-29afc6d20294', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', 'c65792f9-02c8-4be1-84dc-81e5214b1228'),
	('86460dc4-0a54-4a5d-99b6-029fe93035fa', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '7ef0ec07-0491-41ed-98b5-65d069ccb3f1'),
	('21f93b94-f44e-443d-8fe4-2974f46bb575', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '634cd2a3-8d41-4ed9-8814-bb072e31552d'),
	('93ff2606-026f-4e70-8bda-5644d2679ab7', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '0b0cfb2c-edba-4d6c-8b28-26b792ce1bb8'),
	('e821b188-256b-4480-97dd-cf6eae4667fd', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '9540dd86-4493-4d90-80bb-e8f0a29210a9'),
	('16cb5797-012e-4f09-b31a-f7c086857e03', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '3d99342e-b4f0-4d9f-b908-1d91c0b75168'),
	('bcf86ed8-b94b-442a-b0d1-5a3506111a80', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 'bfe6480f-0a58-4f16-ba23-8db03e94c0f2'),
	('6327637d-0882-4e83-9f9c-101f80d7a1c1', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 'b962ba6a-6f85-4cbb-a4fe-66b9bb521b18'),
	('5ef59b06-35a1-4d9f-a556-91a874d357a0', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', '2433730c-ba3d-43d2-9c0c-3bab05a17511'),
	('d380e81f-cc87-4bf7-894d-77ddd1d474ce', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', '6581f59c-7cfe-41c1-ac66-6516d86771e1'),
	('99f09025-9cc7-400f-9162-c00bd573b792', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', '61caf17f-8bdd-4b48-9732-268377133d73'),
	('d22480a3-151b-4b0e-997d-01ed24fb3018', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 'a7876ac2-5b73-4c72-b83e-43590557b858'),
	('1fe5995b-9ab4-4b82-8879-62ec1a2c996e', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 'e49af40c-e9ec-4cc2-af8a-0852fbddb23a'),
	('7fd38df8-5d23-491a-abc3-8f3628227f08', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 'd90c24f6-3a84-4d76-8818-a6067f0b7098'),
	('62d515ea-e172-4294-9567-451bcbfbb278', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', '8b6306f8-90bd-4705-a8fc-e980e59bdb44'),
	('91f8c04e-c7a2-4338-8066-323e688f5988', '9fec09c1-1849-4508-be55-e604dbf087c2', 'bfe6480f-0a58-4f16-ba23-8db03e94c0f2'),
	('40741e37-9537-4ff5-ab4d-ac36230c5946', '9fec09c1-1849-4508-be55-e604dbf087c2', 'd90c24f6-3a84-4d76-8818-a6067f0b7098'),
	('f0f4a9c9-9524-4a90-bb4a-7595eecd9123', '9fec09c1-1849-4508-be55-e604dbf087c2', 'a7876ac2-5b73-4c72-b83e-43590557b858'),
	('7913fe17-59db-4de5-961c-d4997a022e05', '9fec09c1-1849-4508-be55-e604dbf087c2', 'e49af40c-e9ec-4cc2-af8a-0852fbddb23a'),
	('693cee6a-0a5c-4608-af60-0bfd92d8083d', '9fec09c1-1849-4508-be55-e604dbf087c2', 'b962ba6a-6f85-4cbb-a4fe-66b9bb521b18'),
	('dcc5d651-7736-43bb-a485-e75fce29b142', '9fec09c1-1849-4508-be55-e604dbf087c2', '61caf17f-8bdd-4b48-9732-268377133d73'),
	('d2d4fc01-f351-49ee-a842-2e8b15bb3462', '9fec09c1-1849-4508-be55-e604dbf087c2', '2433730c-ba3d-43d2-9c0c-3bab05a17511'),
	('cd7a2565-1fb8-4809-8507-7d07a7c43cb8', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', 'bfe6480f-0a58-4f16-ba23-8db03e94c0f2'),
	('6c2e24ad-8ce3-41eb-a3af-79922f0f6eba', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'f5ea5698-72a1-4205-ac59-b0f10d4deb50'),
	('e0afa368-d5f5-413a-af5e-3fe275431ce0', '0a138b95-9642-48fd-8a6d-ed0810638b5a', 'c5b159e8-6431-4a85-ad94-f88352e5c51f'),
	('f5a0bb72-b406-436f-8a1c-9af1acf6fef6', '0a138b95-9642-48fd-8a6d-ed0810638b5a', '9c8c46f0-f25c-4c54-baf8-57bc680b0f1c'),
	('1d25f768-54c3-474a-996f-9ce7ba4711e6', '0a138b95-9642-48fd-8a6d-ed0810638b5a', '9540dd86-4493-4d90-80bb-e8f0a29210a9'),
	('81c75be5-b782-4d14-b24a-feb3842bfe13', '0a138b95-9642-48fd-8a6d-ed0810638b5a', 'c65792f9-02c8-4be1-84dc-81e5214b1228'),
	('1d9e4a54-ee22-47bb-9ab8-371451ef46d7', '0a138b95-9642-48fd-8a6d-ed0810638b5a', '634cd2a3-8d41-4ed9-8814-bb072e31552d'),
	('783666ea-7d11-4247-85b5-0f06bba83c3b', '0a138b95-9642-48fd-8a6d-ed0810638b5a', '0b0cfb2c-edba-4d6c-8b28-26b792ce1bb8'),
	('a28b18ef-3769-4076-a476-8a033adefb1c', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '9cb84904-cac3-4621-8434-5ba3bb37ea90'),
	('d8a2086b-c2ff-4574-9a1c-9893b4603f82', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '8767afb5-627a-4132-85df-007da2b170dc'),
	('29605295-751a-4102-acfd-74c10892533d', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '99ad481f-ff0d-43a3-a53d-5880d6437357'),
	('4e9e2167-2364-47dd-986a-cd3dfc9388ed', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'db8e313a-02c9-49f4-acf3-185ba95cd531'),
	('b450fb70-751a-4e7f-8af9-4d6bdcae98f4', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'f1902097-0975-4553-84d0-6681fa6f1d98'),
	('a7359169-28c9-4a51-b9c1-64520d0468f3', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'dc76d32f-fa20-41c2-9967-d77f764ce21f'),
	('e8a9e72f-2a65-498b-816b-28501cd4f1ee', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 'a736b77e-a727-467b-9248-5a7d969dfe0b'),
	('7008896b-f603-48c6-a7d5-d4c5d697c10c', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '9254982c-f4be-4a53-84e2-6ffcd7a51c9d'),
	('43713133-272a-483b-ba2a-dd8e13bcf9cd', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '38961f9f-d453-4973-9030-78c443882f54'),
	('aa662be6-db70-44f1-a414-1f1cf231ee3a', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', 'b962ba6a-6f85-4cbb-a4fe-66b9bb521b18'),
	('2cded4ee-46da-4486-944a-b82007244fe7', '44b24dc3-0cea-482b-a666-943701ffa25d', '9540dd86-4493-4d90-80bb-e8f0a29210a9'),
	('d186a045-f12f-4809-9f8f-e8f1945baf8d', '44b24dc3-0cea-482b-a666-943701ffa25d', 'c5b159e8-6431-4a85-ad94-f88352e5c51f'),
	('fb1fd966-52b1-4e44-92ab-a2cc92adb8c9', '44b24dc3-0cea-482b-a666-943701ffa25d', '634cd2a3-8d41-4ed9-8814-bb072e31552d'),
	('9904cb63-ee2a-4bfc-b26c-c4c4e25261a6', '44b24dc3-0cea-482b-a666-943701ffa25d', '0b0cfb2c-edba-4d6c-8b28-26b792ce1bb8'),
	('9861dc51-0d56-4fb7-be62-b7183fa07e32', '44b24dc3-0cea-482b-a666-943701ffa25d', '9c8c46f0-f25c-4c54-baf8-57bc680b0f1c'),
	('f0af5240-4f12-41c5-9509-6f37a5e7f1fd', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '2cb05ecc-dcb6-4c9d-8ebe-36841edbc890'),
	('ae999f93-e1f7-4d04-b593-566218bae984', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 'acd773ad-2232-478c-bd52-953790b7ad83'),
	('a9cac20d-0290-4fc7-bcd5-27b1a74ed3df', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 'f680afbd-d8d6-4310-9d0a-a398e013e5ab'),
	('7ffb25f1-3856-4848-9a5b-f2a3c70d1679', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '0b18f949-1172-48d9-99c1-76eb050962c4'),
	('7941dfcf-ba9c-462c-b286-192c6105d776', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '6f355d49-dd22-4ffa-9ef1-76ef19d0cc60'),
	('a3b1c3ac-6098-4be7-acc6-b7c4525b82c2', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '3696ac77-81db-46cf-a13f-505907037ac9'),
	('837ec55e-a017-4c64-b260-fa687b8df9f6', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '89c20c7e-e37b-467c-a816-59a56f2f9aa1'),
	('9b0b8df5-8c58-4bf5-a9f2-d1c814f10894', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 'b7077a01-54c8-453c-9e28-2c47be0ba91e'),
	('4ab55004-f233-4d6c-82cd-e42a3f9cdb0d', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', 'e70cc3e4-54d0-475f-8d0e-ca63f497f53b'),
	('24eca99f-e7d3-4275-88b2-f030a0d74ba3', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '82576520-b4f3-4a98-a72d-b4fc84149876'),
	('23ab8a2d-06ae-446e-8904-a6cb64601b88', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', '2433730c-ba3d-43d2-9c0c-3bab05a17511'),
	('0092c9e3-35e9-4124-92ee-b2de177c2fc5', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', '61caf17f-8bdd-4b48-9732-268377133d73'),
	('1940e40e-c567-476e-9e16-5bdba55d11dc', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', 'a7876ac2-5b73-4c72-b83e-43590557b858'),
	('c3b3a283-abd2-4196-b838-ea33486c6a67', '6efcabad-bfce-42c7-b503-b4887880c474', '2cb05ecc-dcb6-4c9d-8ebe-36841edbc890'),
	('52e8eedd-c243-40df-ab15-ddcf9e212f31', '6efcabad-bfce-42c7-b503-b4887880c474', 'e70cc3e4-54d0-475f-8d0e-ca63f497f53b'),
	('e5a91334-8e8b-434c-b3a3-ce5ddef9e0cf', '6efcabad-bfce-42c7-b503-b4887880c474', '82576520-b4f3-4a98-a72d-b4fc84149876'),
	('f8f6fe28-45e9-4d8e-8aaf-98fb7b9fd18f', '6efcabad-bfce-42c7-b503-b4887880c474', 'b7077a01-54c8-453c-9e28-2c47be0ba91e'),
	('0ca80904-4b3e-409b-b27e-72aa504dfe61', '6efcabad-bfce-42c7-b503-b4887880c474', '89c20c7e-e37b-467c-a816-59a56f2f9aa1'),
	('aef4383c-b9ee-4a8d-8161-832b2f8a6ef8', '6efcabad-bfce-42c7-b503-b4887880c474', 'f680afbd-d8d6-4310-9d0a-a398e013e5ab'),
	('2ddf7ae7-b92c-40c6-bb47-120de78c4861', '6efcabad-bfce-42c7-b503-b4887880c474', '0b18f949-1172-48d9-99c1-76eb050962c4'),
	('e62da6e9-ca8c-416a-a272-469cc985cc45', '62677e14-1364-463d-bbf4-ffe90731a55b', '47df3718-6b8b-408e-9274-ad3c58d8673d'),
	('fbc82a52-af08-40bf-a77d-4aeb34055440', '62677e14-1364-463d-bbf4-ffe90731a55b', '495784cd-65c5-42a5-9eb3-bd4d871c19bf'),
	('0ac123ec-8dec-42d2-a8c0-e2578522dfd9', '59e073c7-5bb6-4fc9-a963-716f140426f9', '9cb84904-cac3-4621-8434-5ba3bb37ea90'),
	('a07693b9-c8a5-463b-9254-3145a2ca8005', '59e073c7-5bb6-4fc9-a963-716f140426f9', '99ad481f-ff0d-43a3-a53d-5880d6437357'),
	('73da2a0b-8a88-4395-8bc5-71f252a192fa', '59e073c7-5bb6-4fc9-a963-716f140426f9', 'db8e313a-02c9-49f4-acf3-185ba95cd531'),
	('0c6ff5af-8a79-4824-9cd7-d789e5c831c6', '59e073c7-5bb6-4fc9-a963-716f140426f9', 'a736b77e-a727-467b-9248-5a7d969dfe0b'),
	('2fa45cb3-96fe-4a6d-bcad-88f6c966ade7', '59e073c7-5bb6-4fc9-a963-716f140426f9', '8767afb5-627a-4132-85df-007da2b170dc'),
	('9bb49ec8-9074-4cc3-8206-4cec7eb5a698', '59e073c7-5bb6-4fc9-a963-716f140426f9', '9254982c-f4be-4a53-84e2-6ffcd7a51c9d'),
	('5093dae8-0a3f-4f1a-a4c6-92329bd1684e', '59e073c7-5bb6-4fc9-a963-716f140426f9', 'dc76d32f-fa20-41c2-9967-d77f764ce21f'),
	('6e73f288-5f3b-4913-8802-447911389560', '69490190-ffbd-4b86-b99a-f58b077e00e0', 'e70cc3e4-54d0-475f-8d0e-ca63f497f53b'),
	('3b65ad94-8009-4078-b27c-8b2c2b78ef74', '69490190-ffbd-4b86-b99a-f58b077e00e0', '89c20c7e-e37b-467c-a816-59a56f2f9aa1'),
	('0bec5e30-29f5-434f-8dc7-6cefcba1d14c', '69490190-ffbd-4b86-b99a-f58b077e00e0', '0b18f949-1172-48d9-99c1-76eb050962c4'),
	('7d57b4cf-3f34-4046-bed4-117642e53d6f', '69490190-ffbd-4b86-b99a-f58b077e00e0', 'b7077a01-54c8-453c-9e28-2c47be0ba91e'),
	('e1e8ad73-b38f-4781-8cf4-efeaec3be346', '69490190-ffbd-4b86-b99a-f58b077e00e0', '2cb05ecc-dcb6-4c9d-8ebe-36841edbc890'),
	('fe25f29b-006e-45b0-809e-616434658720', '2d915dd9-4476-473b-951a-e7308a01bc80', '9cb84904-cac3-4621-8434-5ba3bb37ea90'),
	('1b2301a7-81c0-4c7c-bc2a-f793558a0752', '2d915dd9-4476-473b-951a-e7308a01bc80', '99ad481f-ff0d-43a3-a53d-5880d6437357'),
	('9ef069f7-0288-46fa-8120-cf64746a6b74', '2d915dd9-4476-473b-951a-e7308a01bc80', '9254982c-f4be-4a53-84e2-6ffcd7a51c9d'),
	('0b4ee9e1-83a9-493c-bdcb-bc5b2f52e29d', '2d915dd9-4476-473b-951a-e7308a01bc80', 'a736b77e-a727-467b-9248-5a7d969dfe0b'),
	('46b8d31b-0850-4c76-b4f8-6aef9073425f', '2d915dd9-4476-473b-951a-e7308a01bc80', 'db8e313a-02c9-49f4-acf3-185ba95cd531'),
	('10145547-981d-404d-a152-8bff104fa08f', '62677e14-1364-463d-bbf4-ffe90731a55b', '7549b1e0-6341-46fd-b411-08fb2efc73df'),
	('942c1d91-00a2-413a-bee1-23e46be164de', '62677e14-1364-463d-bbf4-ffe90731a55b', '979ccbd7-87d7-4c55-a569-4eb75c8fd27e'),
	('710f54dc-3ac0-4932-abf1-6af53aa96872', '62677e14-1364-463d-bbf4-ffe90731a55b', 'bbe408b3-46ae-4806-bf8a-8827f9fbf5ff'),
	('b3d10346-5e6a-4d40-84fb-a66d50972f52', '62677e14-1364-463d-bbf4-ffe90731a55b', '4d95a96b-2d9e-4372-94ed-400c5cc41422'),
	('017649f7-3d20-4a79-9512-c177438f6790', '62677e14-1364-463d-bbf4-ffe90731a55b', '6c58c960-da79-4e00-94eb-c312044a8b46'),
	('3f08a596-c36d-4fec-9684-c11b87cd7547', '62677e14-1364-463d-bbf4-ffe90731a55b', '8dbb4799-ccf9-41ce-a499-65cba06bbd58'),
	('f5692ba1-272c-4275-97fe-8aee2b9f010d', '62677e14-1364-463d-bbf4-ffe90731a55b', 'd7742370-22c1-46e3-8692-d18f33580153'),
	('4a392f5c-55a0-4e24-8f12-23a49993e2de', '62677e14-1364-463d-bbf4-ffe90731a55b', 'f89f89cb-3606-4de1-a437-b19ae6a02647'),
	('3f05613f-4325-4513-a39c-61af51816328', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '6c58c960-da79-4e00-94eb-c312044a8b46'),
	('247e7d3f-2b9b-4a2d-afd6-0be48db6ff11', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '47df3718-6b8b-408e-9274-ad3c58d8673d'),
	('a0b71967-46ae-4092-8272-567aeb01fc85', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '7549b1e0-6341-46fd-b411-08fb2efc73df'),
	('683993bc-d93d-4c85-9ddb-5975c42e0c18', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 'bbe408b3-46ae-4806-bf8a-8827f9fbf5ff'),
	('d8c9d046-1223-4573-a19a-8d0648eaa112', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 'd7742370-22c1-46e3-8692-d18f33580153'),
	('80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '8dbb4799-ccf9-41ce-a499-65cba06bbd58'),
	('0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '979ccbd7-87d7-4c55-a569-4eb75c8fd27e'),
	('e1ea0875-3080-42d7-9252-1b81c56858a5', '8466353c-ad30-45bb-ace6-f8c06d73763d', '979ccbd7-87d7-4c55-a569-4eb75c8fd27e'),
	('b85bf0ec-3426-4ff6-8714-9c687c41f900', '8466353c-ad30-45bb-ace6-f8c06d73763d', '7549b1e0-6341-46fd-b411-08fb2efc73df'),
	('48ead168-d127-4413-b1c9-17ca78b0b26d', '8466353c-ad30-45bb-ace6-f8c06d73763d', '47df3718-6b8b-408e-9274-ad3c58d8673d'),
	('1799d8b8-3a43-48a9-9c4a-f1afa9b8be29', '8466353c-ad30-45bb-ace6-f8c06d73763d', 'bbe408b3-46ae-4806-bf8a-8827f9fbf5ff'),
	('0fb7a1ff-4c79-464d-8c99-5ae06981ed3d', '8466353c-ad30-45bb-ace6-f8c06d73763d', '8dbb4799-ccf9-41ce-a499-65cba06bbd58');


--
-- Data for Name: judges; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."judges" ("id", "event_id", "name", "photo_url", "pin_hash", "revoked", "created_at", "position", "status", "pin", "invite_token") VALUES
	('167c4cb7-153c-4a9f-a914-61b18835d39e', '6b962e43-4457-433b-8326-cd44642d5579', 'Judge 1', NULL, '1455', false, '2026-08-04 23:39:59.127701+00', 1, 'active', '1455', 'e3df8587-6e09-4ee7-a5f0-1c33e239cb6a'),
	('747cf8b1-8dea-461f-939a-56f309abdaae', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 'j1', NULL, '2581', false, '2026-08-05 08:30:48.475415+00', 1, 'active', '2581', '1d11276d-abe3-4463-8f5c-ebf3762adce0'),
	('a71eb07c-e748-4e35-8715-bebcef03b10f', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 'j2', NULL, '3690', false, '2026-08-05 08:30:54.084936+00', 2, 'active', '3690', 'f43fdf47-cc1f-4349-85da-ba3e4aae1454'),
	('89d19a21-3c63-42b5-add0-00e2c643b307', '33791df2-697c-47e5-9ee9-1a2f9f283fce', 'j3', NULL, '6723', false, '2026-08-05 08:31:02.194803+00', 3, 'active', '6723', '62f9b1c6-8f0f-42d1-a91a-59a9c1297742'),
	('03ea9c82-ca24-459e-aee9-5e74b508ceea', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 'Vijayan', NULL, '7120', false, '2026-08-05 19:32:29.308133+00', 1, 'active', '7120', '4f2ce873-e4e0-4dfb-bca2-9b3c0d83ca09'),
	('7aaea42b-62c4-4027-a09e-0f8ad0418128', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 'Dasan', NULL, '6245', false, '2026-08-05 19:32:37.897807+00', 2, 'active', '6245', '6002ce78-2c9f-48fc-86db-98762c19309f'),
	('0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', 'f9f788f4-f4b4-4156-9041-a095a6df7397', 'Mahesh', NULL, '5106', false, '2026-08-05 19:33:12.30299+00', 3, 'active', '5106', '7210d6cf-8397-48cc-89c2-57b6cf82433e'),
	('f788edb3-1a4e-43d6-9afb-41933faac22e', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '1', NULL, '2888', false, '2026-08-05 20:03:13.259193+00', 1, 'active', '2888', 'f9b1f8e2-f7e9-4094-9828-3588ca873ae0'),
	('747e0ee5-59e1-43fc-b023-c0ac3e0f908b', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '2', NULL, '3725', false, '2026-08-05 20:03:17.763961+00', 2, 'active', '3725', '262604f3-9274-47e8-9aca-97b9fd6d7d04'),
	('c93848d3-becc-41d6-b763-afdb5b2a49ae', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', 'q', NULL, '6110', false, '2026-08-17 22:20:18.470466+00', 1, 'active', '6110', '4897b373-9533-4520-8674-5d6439c35477'),
	('684ab909-92c0-4d21-8241-6c4ac085574c', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', 'Parvathy', NULL, '1390', false, '2026-08-20 10:52:54.824075+00', 1, 'active', '1390', '6cfb347b-b6e2-4025-9b0f-2254bdb61b12'),
	('40575c13-ad56-41a8-aa77-58dc77ee09ea', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', 'Shwetha', NULL, '3999', false, '2026-08-21 16:04:38.892946+00', 1, 'active', '3999', '625a9323-ebc8-4901-9ef6-37ec69adb750'),
	('e32097b1-1e41-4099-9b26-9e6dce0f2104', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', 'Matha', NULL, '6582', false, '2026-08-21 18:55:03.646443+00', 1, 'active', '6582', '19259b2f-4cd2-49a8-9c29-c4e5675f3026'),
	('61675d58-1bcf-4233-927b-e48fc6181d09', 'f9fd94fb-ac1d-4e44-9ba6-4eb5c22fbfce', 'Pitha', NULL, '2758', false, '2026-08-21 18:55:18.254759+00', 2, 'active', '2758', '7aa2d72f-273e-4178-ae46-2a3a68c62131'),
	('c275e289-2a76-4555-ba1d-eac3b9b20d38', 'aa2da173-9a4e-4585-9b49-a04025c135b1', 'Reema', NULL, '8724', false, '2026-08-21 19:32:26.898716+00', 1, 'active', '8724', '806d8007-cbd8-4b7f-b8da-35099dc8a6fb'),
	('62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'aa2da173-9a4e-4585-9b49-a04025c135b1', 'Jo', NULL, '2679', false, '2026-08-21 19:32:30.535319+00', 2, 'active', '2679', '0e695faa-41c8-46ae-ac00-64ce6049d96d');


--
-- Data for Name: entry_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."entry_comments" ("id", "judge_id", "entry_id", "body", "updated_at") VALUES
	('6605c56f-b76b-4445-a82d-99e82c0ed5e9', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '16cb5797-012e-4f09-b31a-f7c086857e03', 'sbbd', '2026-08-05 20:10:46.574+00'),
	('04bb6726-29d5-4628-ab3f-f67b68a4d62a', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '2cded4ee-46da-4486-944a-b82007244fe7', 'bdbd', '2026-08-05 20:16:09.46+00');


--
-- Data for Name: judge_rounds; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: judge_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."judge_sessions" ("token", "judge_id", "event_id", "created_at", "expires_at") VALUES
	('fd83c844-bc07-4bc3-b1e9-e7ec8e8d3e15', '167c4cb7-153c-4a9f-a914-61b18835d39e', '6b962e43-4457-433b-8326-cd44642d5579', '2026-08-04 23:40:59.63438+00', '2026-08-05 11:40:59.63438+00'),
	('0f8cad62-5433-4917-a4b5-e09399cdd156', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '2026-08-05 19:36:05.547562+00', '2026-08-06 07:36:05.547562+00'),
	('42ebb5d5-3882-4f21-94df-b05ffc85fddc', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '2026-08-05 19:36:28.114321+00', '2026-08-06 07:36:28.114321+00'),
	('3e1e2171-1756-4ab0-8b5d-6b5f725fafbc', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', 'f9f788f4-f4b4-4156-9041-a095a6df7397', '2026-08-05 19:37:09.785839+00', '2026-08-06 07:37:09.785839+00'),
	('4dedfa49-ca9a-4b73-8335-d79499209125', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '7ba4b923-b46b-4904-809e-2b552fe1db9c', '2026-08-05 20:07:56.516821+00', '2026-08-06 08:07:56.516821+00'),
	('b3cd4482-487d-44e8-951e-684b9fce9b89', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '2026-08-17 22:24:20.519513+00', '2026-08-18 10:24:20.519513+00'),
	('32016fa8-4809-4bc5-be11-2ab3d55fcacf', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '2026-08-17 22:47:23.637892+00', '2026-08-18 10:47:23.637892+00'),
	('634ee8fb-9af8-4ddb-9111-2488a511cbfb', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'ca9ec90c-7bb8-47b0-89ad-ed9238663939', '2026-08-18 16:13:18.978021+00', '2026-08-19 04:13:18.978021+00'),
	('e8bc4aaa-5c26-4007-8b0b-7144a99ae4fe', '684ab909-92c0-4d21-8241-6c4ac085574c', 'e8adfac7-4389-4be8-ad29-6c4d307082bd', '2026-08-20 10:57:50.479353+00', '2026-08-20 22:57:50.479353+00'),
	('fb91ae4a-d72e-4307-a2c7-e43a83e65c2c', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '0a35c94d-8145-4997-b6b2-75844d0bd3fa', '2026-08-21 16:17:14.461567+00', '2026-08-22 04:17:14.461567+00'),
	('56c97928-3994-4128-a32d-c6a9aca9da3c', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '2026-08-21 19:36:24.754836+00', '2026-08-22 07:36:24.754836+00'),
	('c3058b2a-b550-4b32-a93c-2f8a4e342dba', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'aa2da173-9a4e-4585-9b49-a04025c135b1', '2026-08-21 19:37:00.66317+00', '2026-08-22 07:37:00.66317+00');


--
-- Data for Name: tiebreaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."tiebreaks" ("id", "round_id", "place", "method", "winner_entry_id", "note", "created_at", "status", "tied_entry_ids", "resolved_at") VALUES
	('dc6874b0-5fb0-4582-93aa-ae10a6564136', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', 5, 'judge_vote', 'd8a2086b-c2ff-4574-9a1c-9893b4603f82', 'Decided by the judge', '2026-08-20 10:59:32.331407+00', 'resolved', '{d8a2086b-c2ff-4574-9a1c-9893b4603f82,7008896b-f603-48c6-a7d5-d4c5d697c10c}', '2026-08-20 10:59:43.84+00'),
	('3518f84a-a4a0-4572-ac7a-2918f1786e00', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', 1, 'judge_vote', 'bcf86ed8-b94b-442a-b0d1-5a3506111a80', 'Decided by the judge', '2026-08-21 16:21:49.190501+00', 'resolved', '{bcf86ed8-b94b-442a-b0d1-5a3506111a80,7fd38df8-5d23-491a-abc3-8f3628227f08}', '2026-08-21 16:21:59.685+00'),
	('2d7247a3-9392-402e-bf85-5b77f10f485b', '9fec09c1-1849-4508-be55-e604dbf087c2', 4, 'judge_vote', 'f0f4a9c9-9524-4a90-bb4a-7595eecd9123', 'Decided by the judge', '2026-08-21 16:22:56.352917+00', 'resolved', '{dcc5d651-7736-43bb-a485-e75fce29b142,f0f4a9c9-9524-4a90-bb4a-7595eecd9123,7913fe17-59db-4de5-961c-d4997a022e05}', '2026-08-21 16:23:06.113+00'),
	('a97d0d7c-18ca-4d06-a44f-44d6e7adb90a', '62677e14-1364-463d-bbf4-ffe90731a55b', 4, 'judge_vote', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', 'Panel split, decided by head judge (Reema)', '2026-08-21 19:39:40.369938+00', 'resolved', '{3f08a596-c36d-4fec-9684-c11b87cd7547,f5692ba1-272c-4275-97fe-8aee2b9f010d,4a392f5c-55a0-4e24-8f12-23a49993e2de}', '2026-08-21 19:40:34.438+00'),
	('1590fa16-1ca0-490a-bf9d-d2037787840a', 'a49fc10c-0006-4f85-9319-de52b14d00f2', 5, 'judge_vote', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'Panel split, decided by head judge (Reema)', '2026-08-21 19:41:38.097886+00', 'resolved', '{3f05613f-4325-4513-a39c-61af51816328,d8c9d046-1223-4573-a19a-8d0648eaa112}', '2026-08-21 19:41:47.488+00'),
	('fb96063a-1f8f-4c9f-bd8b-6c22c774a944', '8466353c-ad30-45bb-ace6-f8c06d73763d', 2, 'judge_vote', NULL, NULL, '2026-08-21 19:42:17.492331+00', 'open', '{48ead168-d127-4413-b1c9-17ca78b0b26d,e1ea0875-3080-42d7-9252-1b81c56858a5}', NULL);


--
-- Data for Name: judge_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."judge_votes" ("tiebreak_id", "judge_id", "chosen_entry_id", "created_at") VALUES
	('dc6874b0-5fb0-4582-93aa-ae10a6564136', '684ab909-92c0-4d21-8241-6c4ac085574c', 'd8a2086b-c2ff-4574-9a1c-9893b4603f82', '2026-08-20 10:59:43.643143+00'),
	('3518f84a-a4a0-4572-ac7a-2918f1786e00', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'bcf86ed8-b94b-442a-b0d1-5a3506111a80', '2026-08-21 16:21:59.511545+00'),
	('2d7247a3-9392-402e-bf85-5b77f10f485b', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'f0f4a9c9-9524-4a90-bb4a-7595eecd9123', '2026-08-21 16:23:05.928722+00'),
	('a97d0d7c-18ca-4d06-a44f-44d6e7adb90a', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', '2026-08-21 19:40:15.159685+00'),
	('a97d0d7c-18ca-4d06-a44f-44d6e7adb90a', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f08a596-c36d-4fec-9684-c11b87cd7547', '2026-08-21 19:40:34.252536+00'),
	('1590fa16-1ca0-490a-bf9d-d2037787840a', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'd8c9d046-1223-4573-a19a-8d0648eaa112', '2026-08-21 19:41:45.159841+00'),
	('1590fa16-1ca0-490a-bf9d-d2037787840a', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f05613f-4325-4513-a39c-61af51816328', '2026-08-21 19:41:47.349143+00'),
	('fb96063a-1f8f-4c9f-bd8b-6c22c774a944', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e1ea0875-3080-42d7-9252-1b81c56858a5', '2026-08-21 19:42:21.589081+00');


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."scores" ("id", "judge_id", "entry_id", "category_id", "value", "updated_at") VALUES
	('53a0754f-06bb-4fb2-bb42-1afea4f94833', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 4.5, '2026-08-05 19:40:43.777+00'),
	('b3dfbf44-55fc-43f7-bbf7-1b496b84400e', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 8, '2026-08-05 19:42:31.191+00'),
	('8d5c670b-b0f1-4b86-8eb5-eda4f112435f', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 8.5, '2026-08-05 19:40:46.635+00'),
	('3cd7b058-500c-4339-bc64-f41f45a5b96f', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '6e27131a-252d-422f-a6ee-a1d99338b289', '941752fa-f63f-4d9e-b428-22c7519385b1', 5.5, '2026-08-05 19:42:31.384+00'),
	('c0a4b002-2f1f-4d1c-a434-97a976909b79', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '941752fa-f63f-4d9e-b428-22c7519385b1', 4, '2026-08-05 19:40:20.613+00'),
	('bc08a72b-ef77-4c54-9f9c-181521900a63', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '941752fa-f63f-4d9e-b428-22c7519385b1', 10, '2026-08-05 19:40:20.886+00'),
	('71ef148c-92ca-41e3-8259-5d8ef4dc802d', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 5, '2026-08-05 19:41:31.158+00'),
	('7f4556ab-d852-4f80-9fa6-e322cfa2992e', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 4.5, '2026-08-05 19:43:15.892+00'),
	('4b92ee52-98b2-40fc-9081-94719278a106', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 7, '2026-08-05 19:39:53.797+00'),
	('c5580ab1-3d27-4c8d-b203-b2f5451be68b', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '73961840-95de-4046-8806-b6846e4e3658', '941752fa-f63f-4d9e-b428-22c7519385b1', 4, '2026-08-05 19:43:55.236+00'),
	('a867b53f-7811-47f2-80e2-1ad914ae2e15', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'e9ece2ee-293b-4488-a198-622b8d65ded0', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 5, '2026-08-05 19:55:14.086+00'),
	('faa4307b-31df-43e5-a285-b8af96569dd7', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '941752fa-f63f-4d9e-b428-22c7519385b1', 6, '2026-08-05 19:48:03.425+00'),
	('67e9a920-673c-41be-bad8-abc194607005', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '941752fa-f63f-4d9e-b428-22c7519385b1', 7, '2026-08-05 19:41:14.095+00'),
	('9f032458-1d23-4f4e-a93c-d27c0257bd21', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '82178d66-a561-442f-a03a-3dfd132e2c9f', '941752fa-f63f-4d9e-b428-22c7519385b1', 8, '2026-08-05 19:41:14.491+00'),
	('7799cb6e-f4fe-4582-9d96-9a0bb9be2bfc', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '82178d66-a561-442f-a03a-3dfd132e2c9f', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 7, '2026-08-05 19:42:14.014+00'),
	('bf13f658-ca9d-4481-88e7-08eb22026274', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 9, '2026-08-05 19:40:01.079+00'),
	('4b62b7c9-f05f-4066-8f27-bab258571251', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 2.5, '2026-08-05 19:42:37.644+00'),
	('700b590e-77bb-4897-9d63-b5dd5f910ae5', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 9.5, '2026-08-05 19:46:10.785+00'),
	('1b9ad028-eb23-4d5f-8741-8229b84678a6', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '6e27131a-252d-422f-a6ee-a1d99338b289', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 3.5, '2026-08-05 19:42:16.316+00'),
	('a870e32f-0bf7-4b40-a2e7-e3a5f9425e47', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '941752fa-f63f-4d9e-b428-22c7519385b1', 3.5, '2026-08-05 19:43:25.174+00'),
	('b5e1ca6b-973e-4db1-bb61-aa7b5c5ef464', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '82178d66-a561-442f-a03a-3dfd132e2c9f', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 5.5, '2026-08-05 19:41:18.307+00'),
	('456a4142-dfe9-4898-9446-b9d4fe6a9013', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 9, '2026-08-05 19:45:28.845+00'),
	('ce1a5dc4-3475-4136-93f3-5aacee6974c1', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 8.5, '2026-08-05 19:43:01.803+00'),
	('1c5740e5-cb2b-4be2-bac0-25f887002c57', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6, '2026-08-05 19:40:59.381+00'),
	('cd7c2511-83fa-4d98-9395-88602f07fb32', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '6e27131a-252d-422f-a6ee-a1d99338b289', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 7.5, '2026-08-05 19:44:40.207+00'),
	('432d45d2-f4fb-4c40-92ad-afb33d88b93f', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 4.5, '2026-08-05 19:40:09.269+00'),
	('d93f6044-c37a-420c-8a9c-d03a93dcb561', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 8.5, '2026-08-05 19:41:00.592+00'),
	('ffbede3d-ab63-4bb3-b2d0-9b99dff0f5c0', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '73961840-95de-4046-8806-b6846e4e3658', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 4.5, '2026-08-05 19:41:59.595+00'),
	('c353d152-6c58-4732-b0f8-cc9172e0029e', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '1c2bd9c7-0567-4e6e-8080-3347802fb40a', '941752fa-f63f-4d9e-b428-22c7519385b1', 4.5, '2026-08-05 19:40:38.5+00'),
	('bdca7ac8-b467-4143-a30c-faa889ef9767', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '941752fa-f63f-4d9e-b428-22c7519385b1', 4, '2026-08-05 19:40:38.575+00'),
	('147427a6-dce5-4f4e-9f41-3fd1b82cfa98', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '82178d66-a561-442f-a03a-3dfd132e2c9f', '941752fa-f63f-4d9e-b428-22c7519385b1', 8, '2026-08-05 19:41:59.99+00'),
	('6ea56baa-70a0-45a9-8015-e82116291dff', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '941752fa-f63f-4d9e-b428-22c7519385b1', 7.5, '2026-08-05 19:42:44.529+00'),
	('9f79eff7-a164-40db-a56e-6f68879f3d8f', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '73961840-95de-4046-8806-b6846e4e3658', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 4, '2026-08-05 19:44:04.851+00'),
	('05de9cdf-074b-4175-ab42-1e7fe9cb0849', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '82178d66-a561-442f-a03a-3dfd132e2c9f', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 5.5, '2026-08-05 19:42:23.314+00'),
	('8e6ca2a7-a2bf-4c25-b3da-ce1de387ab1d', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '82178d66-a561-442f-a03a-3dfd132e2c9f', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 7.5, '2026-08-05 19:41:44.295+00'),
	('500ec186-1b01-4034-8893-bb967566821f', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '6e27131a-252d-422f-a6ee-a1d99338b289', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 1.5, '2026-08-05 19:44:08.643+00'),
	('16104952-55c5-403b-afc7-86f01581c8f2', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 5.5, '2026-08-05 19:42:05.362+00'),
	('61d664b5-d42f-4ead-ba41-fa0fc0ba0f77', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '82178d66-a561-442f-a03a-3dfd132e2c9f', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 6.5, '2026-08-05 19:43:06.315+00'),
	('872d7afc-c642-419d-8a90-fff76b584482', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6, '2026-08-05 19:41:27.071+00'),
	('d2e1614a-647e-4296-8747-b0a628a0b1ae', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 7, '2026-08-05 19:41:27.708+00'),
	('8457bada-2194-4509-b715-5591202e5567', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '941752fa-f63f-4d9e-b428-22c7519385b1', 6.5, '2026-08-05 19:41:47.825+00'),
	('4348606c-d68a-4c32-b21a-f0a32df1def3', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '7d632118-89b1-4c64-95a9-7f07fba1dac7', '941752fa-f63f-4d9e-b428-22c7519385b1', 9, '2026-08-05 19:41:48.166+00'),
	('cc0bb1f2-73f0-4af4-9e10-2985da1afdd2', '0d3f3dae-054e-4afb-8a73-9bff4fef8d2e', '73961840-95de-4046-8806-b6846e4e3658', '941752fa-f63f-4d9e-b428-22c7519385b1', 2.5, '2026-08-05 19:42:07.704+00'),
	('848bb0c2-3c46-4365-b735-a639ee4370be', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '18cc7a70-fe6a-4fcd-8ad5-f34fc9545607', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 7, '2026-08-05 19:43:39.249+00'),
	('38617472-deae-44fd-bd8e-173a222ca3cb', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 5, '2026-08-05 19:47:10.301+00'),
	('d7a9c8f2-3d05-4399-a9a8-3be5b321f1d0', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '941752fa-f63f-4d9e-b428-22c7519385b1', 5, '2026-08-05 19:45:54.942+00'),
	('964c4ed0-5e8d-4c92-8200-69c3ce177591', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '73961840-95de-4046-8806-b6846e4e3658', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 3, '2026-08-05 19:43:46.874+00'),
	('b9f2e7e0-2873-4b22-b9a0-dccdc3cda562', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '82178d66-a561-442f-a03a-3dfd132e2c9f', '941752fa-f63f-4d9e-b428-22c7519385b1', 7, '2026-08-05 19:42:54.167+00'),
	('2a807247-22b2-46fd-a570-7aa9e19063e8', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '73961840-95de-4046-8806-b6846e4e3658', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6.5, '2026-08-05 19:43:14.114+00'),
	('49fdb2d6-c6c5-464c-8adb-80017306a99a', '7aaea42b-62c4-4027-a09e-0f8ad0418128', '6e27131a-252d-422f-a6ee-a1d99338b289', '941752fa-f63f-4d9e-b428-22c7519385b1', 6, '2026-08-05 19:44:26.3+00'),
	('1e183218-c750-4e31-81e1-0e14bfbb351e', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '941752fa-f63f-4d9e-b428-22c7519385b1', 8, '2026-08-05 19:45:11.401+00'),
	('7a84583f-ab3b-41a7-987a-d768fdc828e8', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 4.5, '2026-08-05 19:47:35.917+00'),
	('d690ee76-8bbd-4533-8f80-12c31cb7aa53', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd2978b0a-6d76-46dc-bd91-d80cf460235f', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 6.5, '2026-08-05 19:47:13.059+00'),
	('1f81ed6a-a102-4bea-990d-5258be99ceea', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '941752fa-f63f-4d9e-b428-22c7519385b1', 7, '2026-08-05 19:47:25.985+00'),
	('5e4e8415-e409-4b8d-9308-26f6fdd2545f', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd6d6da14-e005-44a8-9208-3c5a9b2fa77b', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 9.5, '2026-08-05 19:44:55.376+00'),
	('949ba3bb-250e-401b-a991-9731688c55da', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6.5, '2026-08-05 19:45:43.14+00'),
	('5526ddb9-b065-4688-baab-f6288f5d10c7', '03ea9c82-ca24-459e-aee9-5e74b508ceea', '73961840-95de-4046-8806-b6846e4e3658', '941752fa-f63f-4d9e-b428-22c7519385b1', 2.5, '2026-08-05 19:46:37.018+00'),
	('083c85de-e3c3-4545-af13-fd5c710df06b', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd2978b0a-6d76-46dc-bd91-d80cf460235f', '941752fa-f63f-4d9e-b428-22c7519385b1', 9, '2026-08-05 19:46:59.057+00'),
	('54843c3b-0bda-40d7-8cf9-c82c507278c5', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 4.5, '2026-08-05 19:47:48.043+00'),
	('17d65b2c-6ee6-4442-bfb0-ef6880a94766', '7aaea42b-62c4-4027-a09e-0f8ad0418128', 'd2978b0a-6d76-46dc-bd91-d80cf460235f', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6, '2026-08-05 19:46:38.864+00'),
	('20e949fa-7477-40b9-850d-8de44ffde01c', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '073669c5-5c65-4db8-8b88-96c2547f5f48', '005ab4d2-5aaa-4477-92fd-350956ba965e', 4, '2026-08-05 20:08:20.44+00'),
	('87bc6057-c0c0-4395-b7dc-fddb372fb84e', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'd2978b0a-6d76-46dc-bd91-d80cf460235f', '941752fa-f63f-4d9e-b428-22c7519385b1', 3, '2026-08-05 19:48:37.683+00'),
	('8de1e44d-687b-4a56-b96a-c26c28f75d83', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'f2a51dcf-9c77-47cc-9c7f-33db21ad2eec', '851c526d-ea44-4807-9fd0-5dcad8b722c8', 5, '2026-08-05 19:48:17.237+00'),
	('ec1fe134-f8c7-414a-ba85-c595a9be2921', '03ea9c82-ca24-459e-aee9-5e74b508ceea', 'd2978b0a-6d76-46dc-bd91-d80cf460235f', '9ec8dd1f-5f58-47fc-8119-7f176b8bbb54', 6, '2026-08-05 19:48:31.969+00'),
	('b94cd0cd-ea47-474e-8036-249c76805599', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '073669c5-5c65-4db8-8b88-96c2547f5f48', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 3, '2026-08-05 20:08:10.683+00'),
	('6d47600c-9054-4221-96df-9689c5f9a001', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '0ae2e4b8-7a52-4b58-9e04-277f1d374265', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2, '2026-08-05 20:08:42.235+00'),
	('620c6279-0d16-4af8-b30c-aa0425a22786', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '073669c5-5c65-4db8-8b88-96c2547f5f48', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 4.5, '2026-08-05 20:08:31.79+00'),
	('3c024712-18c2-403a-9d74-36972cef5007', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '0ae2e4b8-7a52-4b58-9e04-277f1d374265', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:08:37.385+00'),
	('86080b69-2d53-4250-899e-d71271cb8080', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '0ae2e4b8-7a52-4b58-9e04-277f1d374265', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 3, '2026-08-05 20:08:48.702+00'),
	('5be7a8af-5b5f-463d-99d7-25118b181443', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '35632d85-9b61-4a27-80cd-7c1227cfd96e', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 1, '2026-08-05 20:08:50.771+00'),
	('4ee1d718-95db-47cf-ab44-41416bc9659f', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '35632d85-9b61-4a27-80cd-7c1227cfd96e', '005ab4d2-5aaa-4477-92fd-350956ba965e', 1, '2026-08-05 20:08:53.399+00'),
	('48bfd427-8469-4a3d-a090-6fa98bafafca', '684ab909-92c0-4d21-8241-6c4ac085574c', '29605295-751a-4102-acfd-74c10892533d', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 8, '2026-08-20 10:58:33.837+00'),
	('23449a59-9a0e-4794-98f9-11f644514764', '684ab909-92c0-4d21-8241-6c4ac085574c', '4e9e2167-2364-47dd-986a-cd3dfc9388ed', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 23.5, '2026-08-20 10:58:36.99+00'),
	('8ebd99ef-14e7-4e28-a0b7-acc573a21737', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd186a045-f12f-4809-9f8f-e8f1945baf8d', '0fbf97a7-c0c0-41a3-8993-8e42c789ad13', 1.5, '2026-08-05 20:13:57.129+00'),
	('c0ff6416-b410-4c05-a267-0f17a23ec33b', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '35632d85-9b61-4a27-80cd-7c1227cfd96e', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:08:58.68+00'),
	('d40241e8-b29e-45e5-9ae1-6bdcfc929b71', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e821b188-256b-4480-97dd-cf6eae4667fd', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 3, '2026-08-05 20:10:19.279+00'),
	('a7338eda-7b32-452f-8701-8d1547f080f0', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '698a04d2-9078-4790-94bf-614fd1a8ba80', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2, '2026-08-05 20:09:04.245+00'),
	('c128a3f3-8805-4438-9b2f-9ff3c5c479d9', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '698a04d2-9078-4790-94bf-614fd1a8ba80', '005ab4d2-5aaa-4477-92fd-350956ba965e', 1, '2026-08-05 20:09:06.398+00'),
	('ff327c85-2235-475f-a4b6-c345ee3ea65e', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '837ec55e-a017-4c64-b260-fa687b8df9f6', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 9.5, '2026-08-17 22:28:21.501+00'),
	('ace11bb6-31ba-491f-9f67-3694837ad5c4', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '81c75be5-b782-4d14-b24a-feb3842bfe13', '9c516fb7-9e36-4283-90e0-987d68050676', 2.5, '2026-08-05 20:11:52.915+00'),
	('fa146052-51b8-49ef-a449-2d392503d3e8', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '698a04d2-9078-4790-94bf-614fd1a8ba80', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:09:11.652+00'),
	('1875de5b-af91-49a5-a746-4031c49dd3ed', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e821b188-256b-4480-97dd-cf6eae4667fd', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2.5, '2026-08-05 20:10:25.097+00'),
	('f2b36866-43a9-4038-985e-2282b54c4dd8', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd5ebf7d5-2e63-4baf-ad3c-29afc6d20294', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:09:17.886+00'),
	('9bc999c2-3b4c-4132-a543-fdfe239f2550', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '7941dfcf-ba9c-462c-b286-192c6105d776', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 6.5, '2026-08-17 22:27:46.69+00'),
	('f8c2d70a-19f7-42b6-95dc-cb279fd21a55', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e821b188-256b-4480-97dd-cf6eae4667fd', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2, '2026-08-05 20:10:31.082+00'),
	('158ffa4b-6134-4e75-86b8-058326e44247', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd5ebf7d5-2e63-4baf-ad3c-29afc6d20294', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2, '2026-08-05 20:09:22.725+00'),
	('55dc5b2b-db0f-4440-a03a-668e2c09088d', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '81c75be5-b782-4d14-b24a-feb3842bfe13', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 1.5, '2026-08-05 20:11:56.203+00'),
	('0a4b9566-ada1-4bb7-a467-1b5cb4b2926c', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd5ebf7d5-2e63-4baf-ad3c-29afc6d20294', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2, '2026-08-05 20:09:27.049+00'),
	('c07527cb-90a7-4e2b-ae02-a869bc4c1243', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '86460dc4-0a54-4a5d-99b6-029fe93035fa', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2, '2026-08-05 20:09:31.393+00'),
	('c1b8e008-3738-4e53-b61e-c3353ba6e1d1', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '16cb5797-012e-4f09-b31a-f7c086857e03', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:10:36.61+00'),
	('fa9ac8be-2367-4066-b5f1-f90f394c1c0d', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '86460dc4-0a54-4a5d-99b6-029fe93035fa', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2, '2026-08-05 20:09:35.979+00'),
	('1c83a408-46e0-4aea-8a20-0487905d5143', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '81c75be5-b782-4d14-b24a-feb3842bfe13', '431338e5-ad04-40be-8954-57d2ad3481f6', 1.5, '2026-08-05 20:11:59.479+00'),
	('a156284f-423f-4fd0-a67c-96726971c82f', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '86460dc4-0a54-4a5d-99b6-029fe93035fa', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2, '2026-08-05 20:09:40.29+00'),
	('8044d0fd-7936-48cf-b542-058ddca1a072', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '16cb5797-012e-4f09-b31a-f7c086857e03', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2, '2026-08-05 20:10:41.135+00'),
	('b702b716-823a-41e1-841b-13e8b1e60a1d', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'fb1fd966-52b1-4e44-92ab-a2cc92adb8c9', '0fbf97a7-c0c0-41a3-8993-8e42c789ad13', 2.5, '2026-08-05 20:14:27.926+00'),
	('2722dc3f-a663-419b-a1a3-7e0c23b1a46b', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '21f93b94-f44e-443d-8fe4-2974f46bb575', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2.5, '2026-08-05 20:09:45.733+00'),
	('ede30a86-d1b6-444c-8366-715ee78a97c9', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd186a045-f12f-4809-9f8f-e8f1945baf8d', '44cf679c-61fb-42a6-9b2e-b2b01058c494', 2.5, '2026-08-05 20:14:03.18+00'),
	('0e4e8043-3311-4892-94de-10202903f0fc', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '16cb5797-012e-4f09-b31a-f7c086857e03', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2, '2026-08-05 20:10:45.791+00'),
	('e00127bf-b0f2-4b6c-acd1-2a8b26fef272', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '21f93b94-f44e-443d-8fe4-2974f46bb575', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2.5, '2026-08-05 20:09:51.719+00'),
	('5dc71443-faca-488f-b762-03b4bd3a067a', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '21f93b94-f44e-443d-8fe4-2974f46bb575', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 1.5, '2026-08-05 20:09:55.333+00'),
	('c5d04574-8647-4317-806a-262339dfb937', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d9e4a54-ee22-47bb-9ab8-371451ef46d7', '9c516fb7-9e36-4283-90e0-987d68050676', 2.5, '2026-08-05 20:12:05.707+00'),
	('c6cbdb30-8ecd-4df1-a34e-67c174eaf51f', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '93ff2606-026f-4e70-8bda-5644d2679ab7', 'ffa233c0-fefa-45c4-86f2-2dcb5b6fcb2a', 2, '2026-08-05 20:09:59.783+00'),
	('698da455-eb21-4154-af25-b1cd4cb5a491', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e0afa368-d5f5-413a-af5e-3fe275431ce0', '9c516fb7-9e36-4283-90e0-987d68050676', 3, '2026-08-05 20:11:22.49+00'),
	('6078e09f-f04d-44f8-8e8a-089cd407ddd3', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '93ff2606-026f-4e70-8bda-5644d2679ab7', '005ab4d2-5aaa-4477-92fd-350956ba965e', 2, '2026-08-05 20:10:04.926+00'),
	('88d4fa36-1d70-45e5-8fff-0399a4a912c4', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'a9cac20d-0290-4fc7-bcd5-27b1a74ed3df', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 7.5, '2026-08-17 22:27:16.848+00'),
	('eb4a198e-3c4e-444e-bd8b-f001f04ec2a4', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '93ff2606-026f-4e70-8bda-5644d2679ab7', '94fddb8a-a274-4c2b-b6f6-6776a06a9379', 2.5, '2026-08-05 20:10:11.397+00'),
	('e8d05baa-0c24-4853-bff0-db8b4ee21065', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e0afa368-d5f5-413a-af5e-3fe275431ce0', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 2, '2026-08-05 20:11:27.529+00'),
	('30936dac-926c-4ff2-8582-42ef4b1ec8dd', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d9e4a54-ee22-47bb-9ab8-371451ef46d7', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 2.5, '2026-08-05 20:12:12.635+00'),
	('975acdd4-a0a7-4e44-8389-e8c534686866', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9861dc51-0d56-4fb7-be62-b7183fa07e32', 'efda0631-b085-44a7-b0e1-1ae7e409fd44', 2, '2026-08-05 20:14:07.875+00'),
	('3ef247ca-73be-4f43-a2ed-fdb582b37e40', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d9e4a54-ee22-47bb-9ab8-371451ef46d7', '431338e5-ad04-40be-8954-57d2ad3481f6', 2, '2026-08-05 20:12:17.06+00'),
	('87331f38-5593-47f4-b1f1-0bbe5dd6fea5', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'e0afa368-d5f5-413a-af5e-3fe275431ce0', '431338e5-ad04-40be-8954-57d2ad3481f6', 3, '2026-08-05 20:11:34.635+00'),
	('622a225e-3175-4fad-9149-7989906b75bd', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9904cb63-ee2a-4bfc-b26c-c4c4e25261a6', '44cf679c-61fb-42a6-9b2e-b2b01058c494', 2.5, '2026-08-05 20:14:50.58+00'),
	('37865792-623e-4745-900c-9b7013d8b41f', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'f5a0bb72-b406-436f-8a1c-9af1acf6fef6', '9c516fb7-9e36-4283-90e0-987d68050676', 2, '2026-08-05 20:11:39.433+00'),
	('5e344b35-c986-4b69-bc0a-46d4a0603f06', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9861dc51-0d56-4fb7-be62-b7183fa07e32', '0fbf97a7-c0c0-41a3-8993-8e42c789ad13', 2, '2026-08-05 20:14:12.57+00'),
	('1515d2af-b177-4aeb-912d-bb19702bd5e5', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'f5a0bb72-b406-436f-8a1c-9af1acf6fef6', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 2, '2026-08-05 20:11:43.688+00'),
	('1369eadd-473c-4a89-9e95-b73b5cb30ca7', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '783666ea-7d11-4247-85b5-0f06bba83c3b', '9c516fb7-9e36-4283-90e0-987d68050676', 2.5, '2026-08-05 20:12:22.837+00'),
	('7fcc49d0-98f3-427b-8346-2416c708f1f8', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'f5a0bb72-b406-436f-8a1c-9af1acf6fef6', '431338e5-ad04-40be-8954-57d2ad3481f6', 1.5, '2026-08-05 20:11:47.081+00'),
	('8cdc46ec-70db-4247-91fa-df30bc9df2f7', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d25f768-54c3-474a-996f-9ce7ba4711e6', '431338e5-ad04-40be-8954-57d2ad3481f6', 4, '2026-08-05 20:12:53.597+00'),
	('37bb64bf-9b0e-4834-85e1-4bde72205b38', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '783666ea-7d11-4247-85b5-0f06bba83c3b', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 2, '2026-08-05 20:12:27.44+00'),
	('8ace3729-257a-4a31-961b-7c02e83841e8', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'fb1fd966-52b1-4e44-92ab-a2cc92adb8c9', '44cf679c-61fb-42a6-9b2e-b2b01058c494', 2.5, '2026-08-05 20:14:33.381+00'),
	('2c1f49ef-c166-4186-909e-9cee4d3fa3c1', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d25f768-54c3-474a-996f-9ce7ba4711e6', '4afba076-6c0d-4f34-baf3-8a19a714b8d1', 4, '2026-08-05 20:12:55.793+00'),
	('35984b0d-b04b-4184-9782-728d267964ed', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '783666ea-7d11-4247-85b5-0f06bba83c3b', '431338e5-ad04-40be-8954-57d2ad3481f6', 2.5, '2026-08-05 20:12:32.632+00'),
	('ef2b4ecc-513f-4305-985f-57587c10d4c3', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9861dc51-0d56-4fb7-be62-b7183fa07e32', '44cf679c-61fb-42a6-9b2e-b2b01058c494', 2, '2026-08-05 20:14:17.099+00'),
	('045155c4-b753-4f5b-a016-cc47975ff847', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '1d25f768-54c3-474a-996f-9ce7ba4711e6', '9c516fb7-9e36-4283-90e0-987d68050676', 4, '2026-08-05 20:12:59.17+00'),
	('b5582f55-9e69-4f6f-89e3-a1df7357a92a', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '2cded4ee-46da-4486-944a-b82007244fe7', '44cf679c-61fb-42a6-9b2e-b2b01058c494', 10, '2026-08-05 20:15:48.142+00'),
	('26bc0fee-5906-440a-9212-9e823f4d73b1', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'd186a045-f12f-4809-9f8f-e8f1945baf8d', 'efda0631-b085-44a7-b0e1-1ae7e409fd44', 2, '2026-08-05 20:13:54.045+00'),
	('5d714ec0-db54-44a5-adc9-acaf1485261e', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '2cded4ee-46da-4486-944a-b82007244fe7', 'efda0631-b085-44a7-b0e1-1ae7e409fd44', 10, '2026-08-05 20:16:02.105+00'),
	('c9c8b43e-bb6f-4fe8-8f16-d34dd7439fda', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9904cb63-ee2a-4bfc-b26c-c4c4e25261a6', 'efda0631-b085-44a7-b0e1-1ae7e409fd44', 2.5, '2026-08-05 20:14:38.922+00'),
	('04e31639-2460-4a80-b4df-1b84094e96f6', 'f788edb3-1a4e-43d6-9afb-41933faac22e', 'fb1fd966-52b1-4e44-92ab-a2cc92adb8c9', 'efda0631-b085-44a7-b0e1-1ae7e409fd44', 2.5, '2026-08-05 20:14:22.368+00'),
	('528e2bfb-b5e0-429a-acda-96861c246c18', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '7ffb25f1-3856-4848-9a5b-f2a3c70d1679', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 7.5, '2026-08-17 22:27:33.797+00'),
	('b4434197-5cea-483b-93fe-3fd2430f78aa', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '2cded4ee-46da-4486-944a-b82007244fe7', '0fbf97a7-c0c0-41a3-8993-8e42c789ad13', 10, '2026-08-05 20:16:07.318+00'),
	('0ecdf5ee-e208-4697-a586-661bb8b88bd2', 'f788edb3-1a4e-43d6-9afb-41933faac22e', '9904cb63-ee2a-4bfc-b26c-c4c4e25261a6', '0fbf97a7-c0c0-41a3-8993-8e42c789ad13', 2.5, '2026-08-05 20:14:44.604+00'),
	('950cc8f3-88b0-4166-af61-395713dd9473', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'ae999f93-e1f7-4d04-b593-566218bae984', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 6.5, '2026-08-17 22:27:03.318+00'),
	('dba240bf-ceac-4a57-9289-e57ebe4611d5', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f0af5240-4f12-41c5-9509-6f37a5e7f1fd', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 8.5, '2026-08-17 22:26:52.257+00'),
	('125b7383-d75a-4d00-80d3-3d28ba25d07e', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '9b0b8df5-8c58-4bf5-a9f2-d1c814f10894', '75540c6d-d58f-4329-8fc4-81fc05175a3d', 6, '2026-08-17 22:28:44.012+00'),
	('f58d325a-241d-496d-a95f-1646a432c2aa', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '9b0b8df5-8c58-4bf5-a9f2-d1c814f10894', '02380567-59bc-41f2-8130-5f231282e1c9', 6, '2026-08-17 22:28:54.381+00'),
	('ccc2b731-24aa-4f29-9020-26eea6c48bf0', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'a3b1c3ac-6098-4be7-acc6-b7c4525b82c2', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 7.5, '2026-08-17 22:28:02.416+00'),
	('ddf7878c-f874-4c0e-a17f-57fba0349d30', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '9b0b8df5-8c58-4bf5-a9f2-d1c814f10894', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 4.5, '2026-08-17 22:28:31.198+00'),
	('1b815553-c28d-464b-94fd-6334cc26033b', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '4ab55004-f233-4d6c-82cd-e42a3f9cdb0d', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 6, '2026-08-17 22:29:07.419+00'),
	('c674fb09-6d48-4683-b0d0-b949fe358679', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '4ab55004-f233-4d6c-82cd-e42a3f9cdb0d', '75540c6d-d58f-4329-8fc4-81fc05175a3d', 8, '2026-08-17 22:29:22.675+00'),
	('b2a6c435-5171-41a7-9d2d-38d8cb7add25', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '4ab55004-f233-4d6c-82cd-e42a3f9cdb0d', '02380567-59bc-41f2-8130-5f231282e1c9', 8, '2026-08-17 22:29:39.523+00'),
	('4b0609ca-dcb2-4e49-b059-302c9c4d44d7', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '24eca99f-e7d3-4275-88b2-f030a0d74ba3', 'ec0d1f2e-c9ea-4e10-9f81-fd337b7e3388', 9, '2026-08-17 22:29:54.085+00'),
	('6160779b-7ac3-48b0-9cb7-90d55a665974', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '24eca99f-e7d3-4275-88b2-f030a0d74ba3', '75540c6d-d58f-4329-8fc4-81fc05175a3d', 10, '2026-08-17 22:30:07.326+00'),
	('e5ed058b-e244-4b2f-aa27-ffcde148871a', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '24eca99f-e7d3-4275-88b2-f030a0d74ba3', '02380567-59bc-41f2-8130-5f231282e1c9', 1.5, '2026-08-17 22:30:10.417+00'),
	('75771663-64a8-427b-9e20-eff6b86bc246', '684ab909-92c0-4d21-8241-6c4ac085574c', '4e9e2167-2364-47dd-986a-cd3dfc9388ed', '50836093-8e4d-4ca5-8e01-6c880723c764', 8.5, '2026-08-20 10:58:40.882+00'),
	('a7493db6-e01c-4f97-92fd-9ccc63b23e88', '684ab909-92c0-4d21-8241-6c4ac085574c', '4e9e2167-2364-47dd-986a-cd3dfc9388ed', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 7, '2026-08-20 10:58:41.928+00'),
	('144757e2-9e8a-4b44-81e9-d6958854bd77', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '6e73f288-5f3b-4913-8802-447911389560', '3ed4df0c-a0f2-46d7-b9c2-3e6ed9b0dbb6', 5, '2026-08-18 16:28:50.232+00'),
	('77aa8d1d-6b87-41ba-ab65-5de465125b0b', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e1e8ad73-b38f-4781-8cf4-efeaec3be346', '3987eea4-ee46-45f6-8ea7-42bbdc5838d5', 6.5, '2026-08-18 16:24:29.026+00'),
	('637f13fa-698a-458d-bc7d-b8d3f59eec25', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f0af5240-4f12-41c5-9509-6f37a5e7f1fd', 'cf72aec0-3018-4f96-a634-db1c6c750aa7', 8.5, '2026-08-17 22:47:45.568+00'),
	('b4d1d239-3a57-4e09-b69a-1b5bcd99dffe', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'aef4383c-b9ee-4a8d-8161-832b2f8a6ef8', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 6.5, '2026-08-18 16:14:36.659+00'),
	('2d18cfd7-3143-4b3c-b6d0-2186e8d76945', '684ab909-92c0-4d21-8241-6c4ac085574c', 'b450fb70-751a-4e7f-8af9-4d6bdcae98f4', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 19, '2026-08-20 10:58:47.139+00'),
	('bf11487d-4e48-4ca9-80a1-01b9f450d5a0', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f8f6fe28-45e9-4d8e-8aaf-98fb7b9fd18f', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 5.5, '2026-08-18 16:16:05.88+00'),
	('25c2ce4f-e090-4053-93c3-3df4cbf4ffe1', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f0af5240-4f12-41c5-9509-6f37a5e7f1fd', '75540c6d-d58f-4329-8fc4-81fc05175a3d', 4.5, '2026-08-17 22:47:56.169+00'),
	('15a534c2-1ee6-4ca5-828a-a91981ea0426', '684ab909-92c0-4d21-8241-6c4ac085574c', 'b450fb70-751a-4e7f-8af9-4d6bdcae98f4', '50836093-8e4d-4ca5-8e01-6c880723c764', 5.5, '2026-08-20 10:58:49.524+00'),
	('614d00d2-1cc4-4b24-b1c7-dfefbe88114c', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '2ddf7ae7-b92c-40c6-bb47-120de78c4861', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 5.5, '2026-08-18 16:14:46.179+00'),
	('a4b10868-19df-4af2-b6f4-3a0759fa9436', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '52e8eedd-c243-40df-ab15-ddcf9e212f31', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 8.5, '2026-08-18 16:17:11.961+00'),
	('6d9a48f6-1d4f-4498-9d2d-5e81094847bb', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f0af5240-4f12-41c5-9509-6f37a5e7f1fd', '02380567-59bc-41f2-8130-5f231282e1c9', 5, '2026-08-17 22:48:05.747+00'),
	('58defeb0-f364-4417-a5f8-32f9348e48a5', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '3b65ad94-8009-4078-b27c-8b2c2b78ef74', '94410e30-1354-40f0-9796-a40e166a354d', 6.5, '2026-08-18 16:28:12.407+00'),
	('11f1a8ad-3e5e-49f6-ba81-386ccc33bf44', '684ab909-92c0-4d21-8241-6c4ac085574c', 'b450fb70-751a-4e7f-8af9-4d6bdcae98f4', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 6.5, '2026-08-20 10:58:51.184+00'),
	('31dd4ff7-2ff6-44b3-ba2e-1afc7265100f', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '3b65ad94-8009-4078-b27c-8b2c2b78ef74', '3987eea4-ee46-45f6-8ea7-42bbdc5838d5', 4.5, '2026-08-18 16:28:16.81+00'),
	('21360f15-e17a-4f4b-aab5-fbd0aa8da9c0', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f0af5240-4f12-41c5-9509-6f37a5e7f1fd', 'f595a7a0-b290-46f8-aa5d-7d8cb7f2baca', 6.5, '2026-08-17 22:48:14.914+00'),
	('d4c8cd08-df11-4ead-b771-e565a3251a49', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '2ddf7ae7-b92c-40c6-bb47-120de78c4861', '4afb9541-1025-4487-b06f-0e4601e53364', 8.5, '2026-08-18 16:14:57.67+00'),
	('857a3105-8481-48d7-b9fa-741fa6e85341', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e5a91334-8e8b-434c-b3a3-ce5ddef9e0cf', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 5, '2026-08-18 16:19:07.564+00'),
	('06ee794a-a745-4b2b-9151-6c24e5717f75', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '6e73f288-5f3b-4913-8802-447911389560', '94410e30-1354-40f0-9796-a40e166a354d', 4, '2026-08-18 16:28:57.961+00'),
	('76e5d946-5f0e-4ce8-acfe-0ef50e9bb569', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'c3b3a283-abd2-4196-b838-ea33486c6a67', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 5, '2026-08-18 16:13:46.959+00'),
	('4ed83cf6-ba60-490f-84cd-e87335f3699d', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f8f6fe28-45e9-4d8e-8aaf-98fb7b9fd18f', '4afb9541-1025-4487-b06f-0e4601e53364', 8.5, '2026-08-18 16:16:26.159+00'),
	('da94f244-3a7b-4751-973c-862919495c1b', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '2ddf7ae7-b92c-40c6-bb47-120de78c4861', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 4.5, '2026-08-18 16:15:11.012+00'),
	('b70f4aa8-55cf-4926-8ab4-a09a6b501840', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'c3b3a283-abd2-4196-b838-ea33486c6a67', '4afb9541-1025-4487-b06f-0e4601e53364', 2.5, '2026-08-18 16:13:54.078+00'),
	('16de94ca-b1db-4ae8-aa61-67c995351d07', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a7359169-28c9-4a51-b9c1-64520d0468f3', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 18.5, '2026-08-20 10:58:56.154+00'),
	('dbbd963b-2d41-4729-8e02-235ad20a89b2', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a7359169-28c9-4a51-b9c1-64520d0468f3', '50836093-8e4d-4ca5-8e01-6c880723c764', 6.5, '2026-08-20 10:58:57.474+00'),
	('8850b376-0ebf-403b-8ad2-412e51566abd', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a7359169-28c9-4a51-b9c1-64520d0468f3', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 8.5, '2026-08-20 10:58:58.597+00'),
	('65d62dde-51a7-47a6-a472-c092c49356f3', '684ab909-92c0-4d21-8241-6c4ac085574c', 'e8a9e72f-2a65-498b-816b-28501cd4f1ee', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 22, '2026-08-20 10:59:01.618+00'),
	('3db7dca9-c1ca-406a-a1da-9a1bf4275a78', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'f8f6fe28-45e9-4d8e-8aaf-98fb7b9fd18f', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 4, '2026-08-18 16:16:34.338+00'),
	('182f986c-ef8b-4c31-bc3d-7ae981319820', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '0ca80904-4b3e-409b-b27e-72aa504dfe61', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 9, '2026-08-18 16:15:29.101+00'),
	('3be5f92a-e34a-4141-b6ef-5859e23a1167', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'c3b3a283-abd2-4196-b838-ea33486c6a67', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 8, '2026-08-18 16:14:08.877+00'),
	('b7151b55-2323-4717-a570-885f99a27f5d', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e5a91334-8e8b-434c-b3a3-ce5ddef9e0cf', '4afb9541-1025-4487-b06f-0e4601e53364', 5.5, '2026-08-18 16:19:19.443+00'),
	('d7d512ce-07a8-45f6-af84-c2b9448c9310', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e5a91334-8e8b-434c-b3a3-ce5ddef9e0cf', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 0.5, '2026-08-18 16:19:20.951+00'),
	('30146b55-a0f6-4014-bd87-7dbe9d6f5aca', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '3b65ad94-8009-4078-b27c-8b2c2b78ef74', '3ed4df0c-a0f2-46d7-b9c2-3e6ed9b0dbb6', 8, '2026-08-18 16:28:27.773+00'),
	('cb36f4a6-c58c-4188-9bdd-ce40c9a18fa1', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'aef4383c-b9ee-4a8d-8161-832b2f8a6ef8', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 4.5, '2026-08-18 16:14:19.564+00'),
	('9152f269-0c30-43c9-beca-7a850b7b80c4', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '0ca80904-4b3e-409b-b27e-72aa504dfe61', '4afb9541-1025-4487-b06f-0e4601e53364', 5.5, '2026-08-18 16:15:40.729+00'),
	('4e52eb4d-fa57-4b7e-afdc-6b5fc4e899e1', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'aef4383c-b9ee-4a8d-8161-832b2f8a6ef8', '4afb9541-1025-4487-b06f-0e4601e53364', 1.5, '2026-08-18 16:14:24.402+00'),
	('9940d75c-0f06-4490-8810-d601064a3203', '684ab909-92c0-4d21-8241-6c4ac085574c', 'e8a9e72f-2a65-498b-816b-28501cd4f1ee', '50836093-8e4d-4ca5-8e01-6c880723c764', 7.5, '2026-08-20 10:59:04.073+00'),
	('0def9de5-666e-44ea-b954-61b65d82b57e', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '6e73f288-5f3b-4913-8802-447911389560', '3987eea4-ee46-45f6-8ea7-42bbdc5838d5', 8.5, '2026-08-18 16:29:07.848+00'),
	('8090380b-fa2e-43a1-a603-f325815d74c4', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '7d57b4cf-3f34-4046-bed4-117642e53d6f', '3ed4df0c-a0f2-46d7-b9c2-3e6ed9b0dbb6', 3.5, '2026-08-18 16:28:32.294+00'),
	('d7b1aaaa-5688-4d31-8ab4-656a5756c8c0', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '52e8eedd-c243-40df-ab15-ddcf9e212f31', '17220c6e-6f8f-4e36-8db6-9b3a5c6486c7', 9, '2026-08-18 16:16:46.869+00'),
	('e8873633-ef31-4f57-89fd-ba6cdf9779a9', '684ab909-92c0-4d21-8241-6c4ac085574c', 'e8a9e72f-2a65-498b-816b-28501cd4f1ee', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 7.5, '2026-08-20 10:59:05.419+00'),
	('56c6d27d-f8d7-4250-9d15-6c0f830213c7', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e1e8ad73-b38f-4781-8cf4-efeaec3be346', '3ed4df0c-a0f2-46d7-b9c2-3e6ed9b0dbb6', 4.5, '2026-08-18 16:23:16.359+00'),
	('a923b508-1cd4-43bf-b320-b69597bfdfe0', '684ab909-92c0-4d21-8241-6c4ac085574c', '7008896b-f603-48c6-a7d5-d4c5d697c10c', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 18, '2026-08-20 10:59:08.194+00'),
	('df8e011f-5add-4edb-8e96-2b30f212a347', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '0ca80904-4b3e-409b-b27e-72aa504dfe61', '9eada0bb-376f-4f6a-a9ca-0ad4b862ee82', 7.5, '2026-08-18 16:15:54.15+00'),
	('43b038cc-8024-4343-995d-b60f0a2dc53b', '684ab909-92c0-4d21-8241-6c4ac085574c', '7008896b-f603-48c6-a7d5-d4c5d697c10c', '50836093-8e4d-4ca5-8e01-6c880723c764', 8, '2026-08-20 10:59:10.225+00'),
	('24ec4be7-a4ec-40fc-9aa9-89df0f8f96f0', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '7d57b4cf-3f34-4046-bed4-117642e53d6f', '94410e30-1354-40f0-9796-a40e166a354d', 6, '2026-08-18 16:28:38.308+00'),
	('d550f91a-16ea-41c5-8cf5-705ae08e39b6', '684ab909-92c0-4d21-8241-6c4ac085574c', '7008896b-f603-48c6-a7d5-d4c5d697c10c', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 8, '2026-08-20 10:59:11.536+00'),
	('6ad5d9cb-9ba8-496f-a669-8012d9067eac', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '52e8eedd-c243-40df-ab15-ddcf9e212f31', '4afb9541-1025-4487-b06f-0e4601e53364', 7, '2026-08-18 16:16:59.826+00'),
	('9ca84041-30ca-4254-b161-a7b7b825bc96', '684ab909-92c0-4d21-8241-6c4ac085574c', '43713133-272a-483b-ba2a-dd8e13bcf9cd', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 18.5, '2026-08-20 10:59:14.329+00'),
	('780be0d3-befd-4448-9514-cf12baf0eb79', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', 'e1e8ad73-b38f-4781-8cf4-efeaec3be346', '94410e30-1354-40f0-9796-a40e166a354d', 6.5, '2026-08-18 16:24:21.954+00'),
	('e4372179-4f97-4bde-b9b7-1b7cfc547287', '684ab909-92c0-4d21-8241-6c4ac085574c', '43713133-272a-483b-ba2a-dd8e13bcf9cd', '50836093-8e4d-4ca5-8e01-6c880723c764', 7.5, '2026-08-20 10:59:17.836+00'),
	('7017a972-ba94-4a99-9d70-12fb84fbfe79', 'c93848d3-becc-41d6-b763-afdb5b2a49ae', '7d57b4cf-3f34-4046-bed4-117642e53d6f', '3987eea4-ee46-45f6-8ea7-42bbdc5838d5', 6.5, '2026-08-18 16:28:43.83+00'),
	('ce584fed-fe99-43e4-8bee-ce790451847a', '684ab909-92c0-4d21-8241-6c4ac085574c', '43713133-272a-483b-ba2a-dd8e13bcf9cd', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 5.5, '2026-08-20 10:59:19.964+00'),
	('ae825844-40ac-4efb-b505-6462a6a921ab', '684ab909-92c0-4d21-8241-6c4ac085574c', 'fe25f29b-006e-45b0-809e-616434658720', '6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', 34.5, '2026-08-20 11:01:00.528+00'),
	('ed1f4837-d470-4dac-b97d-7df8342b592f', '684ab909-92c0-4d21-8241-6c4ac085574c', 'fe25f29b-006e-45b0-809e-616434658720', '6c4efdcb-f3b1-4146-b9c8-49862dcfa840', 7.5, '2026-08-20 11:01:03.696+00'),
	('7a7a6d2e-5217-4944-bcb1-0227f26c14ad', '684ab909-92c0-4d21-8241-6c4ac085574c', '1b2301a7-81c0-4c7c-bc2a-f793558a0752', '6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', 28, '2026-08-20 11:01:07.889+00'),
	('369c0b66-b62a-487f-a64e-c972faa2ac82', '684ab909-92c0-4d21-8241-6c4ac085574c', '1b2301a7-81c0-4c7c-bc2a-f793558a0752', '6c4efdcb-f3b1-4146-b9c8-49862dcfa840', 9, '2026-08-20 11:01:11.204+00'),
	('aec0449a-97a5-4509-946a-6347caa2826f', '684ab909-92c0-4d21-8241-6c4ac085574c', '46b8d31b-0850-4c76-b4f8-6aef9073425f', '6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', 22, '2026-08-20 11:01:13.224+00'),
	('a76e729c-2535-49a0-a4a6-fd7ab63c4dd5', '684ab909-92c0-4d21-8241-6c4ac085574c', '46b8d31b-0850-4c76-b4f8-6aef9073425f', '6c4efdcb-f3b1-4146-b9c8-49862dcfa840', 7.5, '2026-08-20 11:01:15.929+00'),
	('7ef19d4e-e03f-4194-8d8d-9f03947d314d', '684ab909-92c0-4d21-8241-6c4ac085574c', '0b4ee9e1-83a9-493c-bdcb-bc5b2f52e29d', '6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', 31, '2026-08-20 11:01:18.467+00'),
	('0fab4bfd-528e-4c66-81f0-5d7ff9f8ecf3', '684ab909-92c0-4d21-8241-6c4ac085574c', '0b4ee9e1-83a9-493c-bdcb-bc5b2f52e29d', '6c4efdcb-f3b1-4146-b9c8-49862dcfa840', 8.5, '2026-08-20 11:01:20.706+00'),
	('565c1c62-aeb5-4225-958a-01ab57946d1b', '684ab909-92c0-4d21-8241-6c4ac085574c', '9ef069f7-0288-46fa-8120-cf64746a6b74', '6c6d51b7-421c-4986-b7cd-49c1e4e4b6bd', 23, '2026-08-20 11:01:25.411+00'),
	('f18c35a5-42e3-4e0e-b671-cb71acf3f467', '684ab909-92c0-4d21-8241-6c4ac085574c', '9ef069f7-0288-46fa-8120-cf64746a6b74', '6c4efdcb-f3b1-4146-b9c8-49862dcfa840', 7.5, '2026-08-20 11:01:27.527+00'),
	('01bdba5a-7bed-4aeb-9421-e36a2c410b31', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'bcf86ed8-b94b-442a-b0d1-5a3506111a80', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 18, '2026-08-21 16:20:38.424+00'),
	('beca7938-5c5b-46c3-81c4-240ef6b9494c', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd380e81f-cc87-4bf7-894d-77ddd1d474ce', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 10.5, '2026-08-21 16:21:14.163+00'),
	('52ef5b6a-84c5-4142-bfe0-4f4762c29086', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd380e81f-cc87-4bf7-894d-77ddd1d474ce', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 8, '2026-08-21 16:21:15.602+00'),
	('2b472f3c-00b0-4f32-9dba-b441852cfde1', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '99f09025-9cc7-400f-9162-c00bd573b792', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 15, '2026-08-21 16:21:20.358+00'),
	('18be7726-062d-450e-8e45-5195256924be', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '99f09025-9cc7-400f-9162-c00bd573b792', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 12.5, '2026-08-21 16:21:21.412+00'),
	('6c5e0456-dc55-47c1-9c22-76067097c094', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '99f09025-9cc7-400f-9162-c00bd573b792', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 8.5, '2026-08-21 16:21:22.554+00'),
	('bc8f76b3-385a-4311-90a4-2a6a998acca9', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd22480a3-151b-4b0e-997d-01ed24fb3018', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 14.5, '2026-08-21 16:21:25.992+00'),
	('d259221f-d2dd-4d3d-ae35-cc2cea89f242', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd22480a3-151b-4b0e-997d-01ed24fb3018', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 18, '2026-08-21 16:21:25.992+00'),
	('6696b778-e200-4f39-8c72-764e58f1b5db', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd22480a3-151b-4b0e-997d-01ed24fb3018', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 8.5, '2026-08-21 16:21:25.992+00'),
	('1ad1ba65-e536-4de3-bb16-5051063459f8', '684ab909-92c0-4d21-8241-6c4ac085574c', '0ac123ec-8dec-42d2-a8c0-e2578522dfd9', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 25.5, '2026-08-20 11:00:06.742+00'),
	('91279f5a-6518-43cc-ad81-fd9e88b29284', '684ab909-92c0-4d21-8241-6c4ac085574c', '0ac123ec-8dec-42d2-a8c0-e2578522dfd9', 'b131832a-4d70-406b-9da9-d04f63836f8b', 15.5, '2026-08-20 11:00:08.425+00'),
	('75ba2a88-ff8b-4015-8e36-a47e9ef78bb5', '684ab909-92c0-4d21-8241-6c4ac085574c', '2fa45cb3-96fe-4a6d-bcad-88f6c966ade7', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 18.5, '2026-08-20 11:00:12.33+00'),
	('5747545b-c5bf-41b6-81d7-bf949e01c334', '684ab909-92c0-4d21-8241-6c4ac085574c', '2fa45cb3-96fe-4a6d-bcad-88f6c966ade7', 'b131832a-4d70-406b-9da9-d04f63836f8b', 14.5, '2026-08-20 11:00:13.459+00'),
	('db18e56a-ccc2-4d76-97bb-59fbaf2c69fb', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a07693b9-c8a5-463b-9254-3145a2ca8005', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 23.5, '2026-08-20 11:00:16.562+00'),
	('37867200-a640-4573-b57b-6560c1b627f1', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a07693b9-c8a5-463b-9254-3145a2ca8005', 'b131832a-4d70-406b-9da9-d04f63836f8b', 15, '2026-08-20 11:00:17.885+00'),
	('859c9850-f99c-4dc4-b9ca-9f52125d0b58', '684ab909-92c0-4d21-8241-6c4ac085574c', '73da2a0b-8a88-4395-8bc5-71f252a192fa', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 21.5, '2026-08-20 11:00:19.776+00'),
	('f98abc7f-436d-4132-ac82-638c9963dae1', '684ab909-92c0-4d21-8241-6c4ac085574c', '73da2a0b-8a88-4395-8bc5-71f252a192fa', 'b131832a-4d70-406b-9da9-d04f63836f8b', 13.5, '2026-08-20 11:00:20.902+00'),
	('37f6d940-684a-4776-ab58-833de31cd42e', '684ab909-92c0-4d21-8241-6c4ac085574c', '5093dae8-0a3f-4f1a-a4c6-92329bd1684e', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 16.5, '2026-08-20 11:00:23.357+00'),
	('87e2d0bc-3c42-4fbb-9961-67f898cbe97c', '684ab909-92c0-4d21-8241-6c4ac085574c', '5093dae8-0a3f-4f1a-a4c6-92329bd1684e', 'b131832a-4d70-406b-9da9-d04f63836f8b', 13, '2026-08-20 11:00:24.693+00'),
	('a8f0e207-40d2-49f6-a220-c6907d2545b8', '684ab909-92c0-4d21-8241-6c4ac085574c', '0c6ff5af-8a79-4824-9cd7-d789e5c831c6', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 23.5, '2026-08-20 11:00:26.448+00'),
	('0fe25e48-a5b4-431e-83d3-650309ae4519', '684ab909-92c0-4d21-8241-6c4ac085574c', '0c6ff5af-8a79-4824-9cd7-d789e5c831c6', 'b131832a-4d70-406b-9da9-d04f63836f8b', 12.5, '2026-08-20 11:00:27.496+00'),
	('93aec43b-aa2c-4506-8bce-4009aebdda9c', '684ab909-92c0-4d21-8241-6c4ac085574c', '9bb49ec8-9074-4cc3-8206-4cec7eb5a698', '9d4f1b54-2917-4a7b-968c-4cbc49c39fa5', 23.5, '2026-08-20 11:00:29.082+00'),
	('8d3e8eef-ea6b-4445-a37a-b0924d693843', '684ab909-92c0-4d21-8241-6c4ac085574c', '9bb49ec8-9074-4cc3-8206-4cec7eb5a698', 'b131832a-4d70-406b-9da9-d04f63836f8b', 13, '2026-08-20 11:00:31.418+00'),
	('9f8ad85d-e55f-4096-9f42-d66e78bc2920', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'bcf86ed8-b94b-442a-b0d1-5a3506111a80', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 14.5, '2026-08-21 16:20:43.665+00'),
	('d53877a1-c805-4418-bfc7-43e1101a8bb8', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'bcf86ed8-b94b-442a-b0d1-5a3506111a80', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 9, '2026-08-21 16:20:46.23+00'),
	('10b34e97-d436-473f-b521-1b41445c1a39', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '6327637d-0882-4e83-9f9c-101f80d7a1c1', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 14, '2026-08-21 16:20:52.922+00'),
	('87d6abaf-bf6b-4a64-86f6-54b0c44dd7ad', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '6327637d-0882-4e83-9f9c-101f80d7a1c1', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 15.5, '2026-08-21 16:20:55.66+00'),
	('ac0537f4-90e8-4fed-bf21-44d9a426fc31', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '6327637d-0882-4e83-9f9c-101f80d7a1c1', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 7, '2026-08-21 16:20:57.742+00'),
	('ad44b5c7-9f00-40b9-b829-1a651ce536d8', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '5ef59b06-35a1-4d9f-a556-91a874d357a0', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 13, '2026-08-21 16:21:02.484+00'),
	('5907c4e9-7f24-48a9-aa4d-e64b6451dad2', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '5ef59b06-35a1-4d9f-a556-91a874d357a0', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 12, '2026-08-21 16:21:03.644+00'),
	('ba14e36c-bf23-43a3-9843-74c1a1ad2cad', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '5ef59b06-35a1-4d9f-a556-91a874d357a0', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 9.5, '2026-08-21 16:21:05.706+00'),
	('c1bcfde9-3f78-4518-a6f9-eb204e262ae9', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'cd7a2565-1fb8-4809-8507-7d07a7c43cb8', 'ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 26, '2026-08-21 16:23:17.955+00'),
	('b970b56b-2c1a-43b4-a2b1-523fd4bfecbc', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd380e81f-cc87-4bf7-894d-77ddd1d474ce', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 12, '2026-08-21 16:21:12.7+00'),
	('c0be6e65-f789-41eb-8024-d9965ef644e7', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '1fe5995b-9ab4-4b82-8879-62ec1a2c996e', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 18, '2026-08-21 16:21:29.059+00'),
	('31fb8ce5-4a77-4b2c-b9ea-e30db582893b', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '1fe5995b-9ab4-4b82-8879-62ec1a2c996e', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 15, '2026-08-21 16:21:29.059+00'),
	('ce84022b-1a38-4c09-a2b2-85cd3e22d6ca', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '1fe5995b-9ab4-4b82-8879-62ec1a2c996e', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 8, '2026-08-21 16:21:29.059+00'),
	('dd977248-5022-4370-86b2-a0fa1f1fbe27', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7fd38df8-5d23-491a-abc3-8f3628227f08', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 15.5, '2026-08-21 16:21:32.16+00'),
	('35be3f34-4bf2-4828-85b2-e098d93e7380', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7fd38df8-5d23-491a-abc3-8f3628227f08', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 18.5, '2026-08-21 16:21:32.16+00'),
	('f409a037-1203-465f-894e-9a69fed3e720', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7fd38df8-5d23-491a-abc3-8f3628227f08', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 7.5, '2026-08-21 16:21:32.16+00'),
	('267454a4-fa28-47c7-8195-20de60d72377', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '62d515ea-e172-4294-9567-451bcbfbb278', '01b62b0d-fa03-4b5e-b8a8-fa5a44829261', 13.5, '2026-08-21 16:21:33.772+00'),
	('d041a2db-b403-4fdc-ac14-42ad4ebfa245', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '62d515ea-e172-4294-9567-451bcbfbb278', 'a92157f6-3202-4c19-8732-908cdb7ec18e', 11, '2026-08-21 16:21:35.216+00'),
	('f3261681-2de0-4501-9bf4-4bf26290bdf6', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '62d515ea-e172-4294-9567-451bcbfbb278', 'fa008ab0-9523-4b1f-9bcb-a879388ffdc4', 7.5, '2026-08-21 16:21:38.088+00'),
	('6504592b-41ce-47bc-b780-76b4f3f6bddd', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '91f8c04e-c7a2-4338-8066-323e688f5988', '47118210-7d94-4b25-9364-a423e229fdea', 17.5, '2026-08-21 16:22:09.827+00'),
	('58cfca20-7e64-4864-b052-adaf2da023d7', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '91f8c04e-c7a2-4338-8066-323e688f5988', '446a0235-2339-4acb-bcdb-a7255b44a6be', 8.5, '2026-08-21 16:22:12.135+00'),
	('1afbcda5-cad4-43aa-8f3d-b4c2144bee76', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '91f8c04e-c7a2-4338-8066-323e688f5988', '95f5faad-fabd-43af-a9f5-53849390a0bd', 9.5, '2026-08-21 16:22:15.433+00'),
	('3273302e-8854-4c12-8743-1cc610e9c5c4', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '693cee6a-0a5c-4608-af60-0bfd92d8083d', '47118210-7d94-4b25-9364-a423e229fdea', 17, '2026-08-21 16:22:19.054+00'),
	('32dafb2f-11fe-4e51-9aec-69f8626d78fa', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '693cee6a-0a5c-4608-af60-0bfd92d8083d', '446a0235-2339-4acb-bcdb-a7255b44a6be', 8, '2026-08-21 16:22:20.544+00'),
	('f2feaf04-083f-4eaf-a122-751300940c91', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '693cee6a-0a5c-4608-af60-0bfd92d8083d', '95f5faad-fabd-43af-a9f5-53849390a0bd', 9, '2026-08-21 16:22:22.346+00'),
	('201a0b60-4134-47a6-8ef2-d3ed8c08b6e7', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd2d4fc01-f351-49ee-a842-2e8b15bb3462', '47118210-7d94-4b25-9364-a423e229fdea', 16, '2026-08-21 16:22:26.431+00'),
	('b83d86ac-5b56-4d7c-b223-580fbd71105e', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd2d4fc01-f351-49ee-a842-2e8b15bb3462', '446a0235-2339-4acb-bcdb-a7255b44a6be', 8.5, '2026-08-21 16:22:28.249+00'),
	('63c888b9-2840-4ca4-90f7-912f420ad4ba', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'd2d4fc01-f351-49ee-a842-2e8b15bb3462', '95f5faad-fabd-43af-a9f5-53849390a0bd', 9, '2026-08-21 16:22:29.405+00'),
	('a6b3ad18-302c-44b2-9308-556c6ea000db', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'dcc5d651-7736-43bb-a485-e75fce29b142', '47118210-7d94-4b25-9364-a423e229fdea', 14.5, '2026-08-21 16:22:35.577+00'),
	('1365201b-08c7-4803-b4e9-b414b535b3f4', '684ab909-92c0-4d21-8241-6c4ac085574c', '6c2e24ad-8ce3-41eb-a3af-79922f0f6eba', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 19, '2026-08-20 10:58:00.705+00'),
	('28faa361-1e83-4929-805a-d4bc8aea4314', '684ab909-92c0-4d21-8241-6c4ac085574c', '6c2e24ad-8ce3-41eb-a3af-79922f0f6eba', '50836093-8e4d-4ca5-8e01-6c880723c764', 8.5, '2026-08-20 10:58:03.338+00'),
	('01e22a7a-c724-4c90-ba59-b0bdb1e8282d', '684ab909-92c0-4d21-8241-6c4ac085574c', '6c2e24ad-8ce3-41eb-a3af-79922f0f6eba', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 6, '2026-08-20 10:58:06.582+00'),
	('bb0ceff8-5690-4e5b-81b8-4f525e0b079d', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a28b18ef-3769-4076-a476-8a033adefb1c', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 27, '2026-08-20 10:58:11.759+00'),
	('6b53e330-f928-4371-93e0-d0268215410a', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a28b18ef-3769-4076-a476-8a033adefb1c', '50836093-8e4d-4ca5-8e01-6c880723c764', 8.5, '2026-08-20 10:58:13.613+00'),
	('e78c5f75-c43c-4ffd-84aa-8c8293ea7e33', '684ab909-92c0-4d21-8241-6c4ac085574c', 'a28b18ef-3769-4076-a476-8a033adefb1c', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 8, '2026-08-20 10:58:15.817+00'),
	('3f82a00f-e194-475a-bddd-0c270a320233', '684ab909-92c0-4d21-8241-6c4ac085574c', 'd8a2086b-c2ff-4574-9a1c-9893b4603f82', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 22.5, '2026-08-20 10:58:20.272+00'),
	('e9ed9c4f-5f01-4945-8234-9329b0ae5900', '684ab909-92c0-4d21-8241-6c4ac085574c', 'd8a2086b-c2ff-4574-9a1c-9893b4603f82', '50836093-8e4d-4ca5-8e01-6c880723c764', 7, '2026-08-20 10:58:23.929+00'),
	('d23b893a-9116-4374-bc20-62a712b9a0d5', '684ab909-92c0-4d21-8241-6c4ac085574c', 'd8a2086b-c2ff-4574-9a1c-9893b4603f82', 'f33bd341-1df5-4e60-abf7-9eb02c4efd0d', 7.5, '2026-08-20 10:58:26.009+00'),
	('b6a4de69-140c-4ac4-8309-3947c3e1153a', '684ab909-92c0-4d21-8241-6c4ac085574c', '29605295-751a-4102-acfd-74c10892533d', '5ab3a2ae-bfcc-4c7d-a488-a4ff7f9c3bb2', 21.5, '2026-08-20 10:58:29.824+00'),
	('17fdaca2-e7c7-489a-b746-a91a50ebadc3', '684ab909-92c0-4d21-8241-6c4ac085574c', '29605295-751a-4102-acfd-74c10892533d', '50836093-8e4d-4ca5-8e01-6c880723c764', 8.5, '2026-08-20 10:58:31.239+00'),
	('9a5c1d61-cbf5-467b-8222-6101a6e8e6d5', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'dcc5d651-7736-43bb-a485-e75fce29b142', '446a0235-2339-4acb-bcdb-a7255b44a6be', 7, '2026-08-21 16:22:36.9+00'),
	('3d7e025d-0580-4aec-9578-62f7d08dc892', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'dcc5d651-7736-43bb-a485-e75fce29b142', '95f5faad-fabd-43af-a9f5-53849390a0bd', 8.5, '2026-08-21 16:22:38.776+00'),
	('9ad53d06-a60e-478f-b99b-def24cc0538f', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'f0f4a9c9-9524-4a90-bb4a-7595eecd9123', '47118210-7d94-4b25-9364-a423e229fdea', 14.5, '2026-08-21 16:22:40.516+00'),
	('e8fbfce2-551d-43e6-90c5-2318083f2022', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'f0f4a9c9-9524-4a90-bb4a-7595eecd9123', '446a0235-2339-4acb-bcdb-a7255b44a6be', 6.5, '2026-08-21 16:22:42.204+00'),
	('e6120e95-cc38-4e8b-b532-87d1de34c332', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'f0f4a9c9-9524-4a90-bb4a-7595eecd9123', '95f5faad-fabd-43af-a9f5-53849390a0bd', 9, '2026-08-21 16:22:44.249+00'),
	('5f9140e0-7db6-4093-b19c-27a72c91f35a', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7913fe17-59db-4de5-961c-d4997a022e05', '47118210-7d94-4b25-9364-a423e229fdea', 16.5, '2026-08-21 16:22:47.337+00'),
	('4e24e8c6-0418-41e2-9f5b-3762345f31d7', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7913fe17-59db-4de5-961c-d4997a022e05', '446a0235-2339-4acb-bcdb-a7255b44a6be', 6.5, '2026-08-21 16:22:48.464+00'),
	('5e3a5b79-658a-4bcd-b607-c8dadc2d3287', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '7913fe17-59db-4de5-961c-d4997a022e05', '95f5faad-fabd-43af-a9f5-53849390a0bd', 7, '2026-08-21 16:22:49.315+00'),
	('458264df-d322-4f35-abc9-7f373cb31810', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '40741e37-9537-4ff5-ab4d-ac36230c5946', '47118210-7d94-4b25-9364-a423e229fdea', 14, '2026-08-21 16:22:53.457+00'),
	('4a7a77de-c73b-41a0-bcdf-c7095f31aedc', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '40741e37-9537-4ff5-ab4d-ac36230c5946', '446a0235-2339-4acb-bcdb-a7255b44a6be', 7.5, '2026-08-21 16:22:53.457+00'),
	('0909d7e0-d480-41e4-a75b-df0cb28bd9a8', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '40741e37-9537-4ff5-ab4d-ac36230c5946', '95f5faad-fabd-43af-a9f5-53849390a0bd', 8, '2026-08-21 16:22:54.339+00'),
	('b6121a36-6fd1-4d0d-bc3d-ec734dfdfa42', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'cd7a2565-1fb8-4809-8507-7d07a7c43cb8', '369eb3a9-25bd-4e00-abe5-6d940e10e653', 18, '2026-08-21 16:23:20.62+00'),
	('88fd26d3-4949-49cb-9faa-c3202f893f2b', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'aa662be6-db70-44f1-a414-1f1cf231ee3a', 'ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 23, '2026-08-21 16:23:23.041+00'),
	('76a0db22-eb04-4cce-9a4f-d0ef0afa80ec', '40575c13-ad56-41a8-aa77-58dc77ee09ea', 'aa662be6-db70-44f1-a414-1f1cf231ee3a', '369eb3a9-25bd-4e00-abe5-6d940e10e653', 17.5, '2026-08-21 16:23:25.231+00'),
	('4b16fa3a-e15c-4b4c-9ad2-d02a336f0964', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '23ab8a2d-06ae-446e-8904-a6cb64601b88', 'ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 21, '2026-08-21 16:23:28.929+00'),
	('59a4901a-a7d1-4a37-92c4-391798a4a643', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '23ab8a2d-06ae-446e-8904-a6cb64601b88', '369eb3a9-25bd-4e00-abe5-6d940e10e653', 16, '2026-08-21 16:23:31.167+00'),
	('fa93d1e3-2f30-49a3-9e9b-25ad76da488b', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'e62da6e9-ca8c-416a-a272-469cc985cc45', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9.5, '2026-08-21 19:36:45.082+00'),
	('b94507fe-4251-451c-86b4-b34e0f4fe648', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '0092c9e3-35e9-4124-92ee-b2de177c2fc5', 'ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 16, '2026-08-21 16:23:37.013+00'),
	('35f8b853-3245-48eb-872e-b8f2f4505367', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '0092c9e3-35e9-4124-92ee-b2de177c2fc5', '369eb3a9-25bd-4e00-abe5-6d940e10e653', 13.5, '2026-08-21 16:23:39.606+00'),
	('883dc666-94ef-4bc5-9bd6-5ec4834a8b0f', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '1940e40e-c567-476e-9e16-5bdba55d11dc', 'ee1ea1f1-08b2-44f1-ba05-dd908e9dea58', 19, '2026-08-21 16:23:41.75+00'),
	('6f9711f3-3ca2-4e57-a4ec-bd95dcb50754', '40575c13-ad56-41a8-aa77-58dc77ee09ea', '1940e40e-c567-476e-9e16-5bdba55d11dc', '369eb3a9-25bd-4e00-abe5-6d940e10e653', 15, '2026-08-21 16:23:44.71+00'),
	('7e49770e-dac5-485f-a2c1-e10295a89ab7', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'e62da6e9-ca8c-416a-a272-469cc985cc45', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9, '2026-08-21 19:36:46.325+00'),
	('bf54e206-fb37-48e4-a3fa-0d67e538c3f2', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'e62da6e9-ca8c-416a-a272-469cc985cc45', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8.5, '2026-08-21 19:36:47.96+00'),
	('ff9cc7aa-c65d-4e1a-90d0-1d949af8d103', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'fbc82a52-af08-40bf-a77d-4aeb34055440', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 6, '2026-08-21 19:37:06.063+00'),
	('d8fb71c7-ab60-4536-9505-99d618014786', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'fbc82a52-af08-40bf-a77d-4aeb34055440', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7, '2026-08-21 19:37:07.561+00'),
	('8f704b3e-034a-4681-b827-870b85dc37d8', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'fbc82a52-af08-40bf-a77d-4aeb34055440', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 6.5, '2026-08-21 19:37:09.156+00'),
	('b64a00f3-50c4-4e63-8738-f64e4c9f23e9', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '10145547-981d-404d-a152-8bff104fa08f', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9, '2026-08-21 19:37:11.697+00'),
	('1791540f-cc21-4f70-b983-36f1206ab953', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '10145547-981d-404d-a152-8bff104fa08f', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9, '2026-08-21 19:37:13.509+00'),
	('df8b8a86-37bf-4715-ab35-9ecc7be31eea', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '10145547-981d-404d-a152-8bff104fa08f', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 9, '2026-08-21 19:37:14.954+00'),
	('83450d08-96e8-49c3-ade2-dcb5650cca8b', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e62da6e9-ca8c-416a-a272-469cc985cc45', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8.5, '2026-08-21 19:37:16.15+00'),
	('adc38b8d-3a5e-4eb4-9eec-dc408dd72a18', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '942c1d91-00a2-413a-bee1-23e46be164de', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8.5, '2026-08-21 19:37:16.997+00'),
	('8359a683-a823-48e8-9900-f953a5e1e30a', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e62da6e9-ca8c-416a-a272-469cc985cc45', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 8.5, '2026-08-21 19:37:18.889+00'),
	('cc716e95-d935-4d3b-ad6f-dc5ca390d779', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '942c1d91-00a2-413a-bee1-23e46be164de', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7, '2026-08-21 19:37:19.09+00'),
	('70899ef1-e357-4d83-a203-c14c930914dc', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e62da6e9-ca8c-416a-a272-469cc985cc45', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 9, '2026-08-21 19:37:20.028+00'),
	('c215ac6c-29ae-43b9-98fe-91b964da9ce7', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '942c1d91-00a2-413a-bee1-23e46be164de', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 7, '2026-08-21 19:37:20.711+00'),
	('98b3e037-decb-451d-88e5-d6e4f36f17c0', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '710f54dc-3ac0-4932-abf1-6af53aa96872', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9.5, '2026-08-21 19:37:22.611+00'),
	('bc4f2b48-32b4-4f1f-871f-36597b510874', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '710f54dc-3ac0-4932-abf1-6af53aa96872', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7.5, '2026-08-21 19:37:24.061+00'),
	('12b6771e-7078-43de-9ec8-5606aa486067', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'fbc82a52-af08-40bf-a77d-4aeb34055440', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8, '2026-08-21 19:37:24.508+00'),
	('00c9dc06-b3e6-45e0-8c5e-26932a805d0d', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '710f54dc-3ac0-4932-abf1-6af53aa96872', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8, '2026-08-21 19:37:25.03+00'),
	('be2300d3-4fe5-4fb5-afc4-820301ec68e6', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'fbc82a52-af08-40bf-a77d-4aeb34055440', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9.5, '2026-08-21 19:37:25.882+00'),
	('e1981019-3343-476b-b859-51701fde1f03', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 6, '2026-08-21 19:37:26.59+00'),
	('05ec6cd7-da18-43ca-b2cc-d6a47bc8f68b', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'fbc82a52-af08-40bf-a77d-4aeb34055440', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8.5, '2026-08-21 19:37:28.031+00'),
	('49db5833-657c-4aa9-ab18-1772e75f9b2f', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7.5, '2026-08-21 19:37:28.604+00'),
	('0c1e4645-a7f9-42f8-80f8-f212e12ebe35', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 5.5, '2026-08-21 19:37:30.035+00'),
	('fed76169-3da9-4dd6-93af-058b71015d11', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '10145547-981d-404d-a152-8bff104fa08f', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9.5, '2026-08-21 19:37:32.429+00'),
	('cc568151-699c-41ed-b509-f0e9c0083f1b', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '10145547-981d-404d-a152-8bff104fa08f', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9.5, '2026-08-21 19:37:34.294+00'),
	('980b8e81-60e8-4e72-bfeb-7549b100858c', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '017649f7-3d20-4a79-9512-c177438f6790', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9.5, '2026-08-21 19:37:34.772+00'),
	('da6c35e4-3335-4ffa-adf7-0ed80b98cec0', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '017649f7-3d20-4a79-9512-c177438f6790', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 9.5, '2026-08-21 19:37:36.095+00'),
	('073e0c68-6616-49b5-9d32-c22f62b96607', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '017649f7-3d20-4a79-9512-c177438f6790', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9, '2026-08-21 19:37:37.731+00'),
	('e6efaa8a-1f63-4f81-ae93-ef09f3a53ed2', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f08a596-c36d-4fec-9684-c11b87cd7547', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 7.5, '2026-08-21 19:37:40.217+00'),
	('8e6c2a4e-c682-4ea4-9f5c-00f92774c410', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f08a596-c36d-4fec-9684-c11b87cd7547', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7, '2026-08-21 19:37:41.179+00'),
	('3eb3cbda-1321-414b-8188-dca0c4477143', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f08a596-c36d-4fec-9684-c11b87cd7547', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8.5, '2026-08-21 19:37:48.169+00'),
	('c66eba33-14b9-496b-a2f1-84566258016e', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '10145547-981d-404d-a152-8bff104fa08f', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 7.5, '2026-08-21 19:37:50.72+00'),
	('bc55f4a1-3a0d-49e6-9e7b-52a5e7102af3', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8, '2026-08-21 19:37:55.643+00'),
	('b3d7cec4-7aa5-487a-9d08-6fe62c1286bf', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 8, '2026-08-21 19:37:58.398+00'),
	('28265ecb-c8fc-4aea-b714-3c30c446e8f5', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8.5, '2026-08-21 19:37:59.744+00'),
	('d4fafca1-bfa1-4f19-8b4d-e74b3a920424', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '942c1d91-00a2-413a-bee1-23e46be164de', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 9.5, '2026-08-21 19:38:03.072+00'),
	('f80c1a04-40a9-4b90-b05c-991f57290988', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '4a392f5c-55a0-4e24-8f12-23a49993e2de', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 9, '2026-08-21 19:38:04.509+00'),
	('3ba3097b-81e0-4f4c-aaab-640cddd863f7', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '942c1d91-00a2-413a-bee1-23e46be164de', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 5.5, '2026-08-21 19:38:05.445+00'),
	('a25ca9be-566a-4e3b-860b-f2b803c05773', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '4a392f5c-55a0-4e24-8f12-23a49993e2de', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7, '2026-08-21 19:38:05.524+00'),
	('481e99b4-1350-47fc-8aa9-0d7dc4a845a2', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '4a392f5c-55a0-4e24-8f12-23a49993e2de', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 6.5, '2026-08-21 19:38:06.659+00'),
	('9a00fae1-c197-4ae9-aa78-2ae5a8a5939f', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '942c1d91-00a2-413a-bee1-23e46be164de', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 7, '2026-08-21 19:38:08.435+00'),
	('cbbc5332-1fa5-4570-9a87-8b2d9dc5bf9b', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '710f54dc-3ac0-4932-abf1-6af53aa96872', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 7, '2026-08-21 19:38:19.015+00'),
	('1bb0521a-efe1-4ae7-96ed-d2bbaff658f5', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '710f54dc-3ac0-4932-abf1-6af53aa96872', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 4.5, '2026-08-21 19:38:19.015+00'),
	('3087073b-7984-4ce7-92f4-a5d2af90de2c', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '710f54dc-3ac0-4932-abf1-6af53aa96872', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 7, '2026-08-21 19:38:19.015+00'),
	('6a5c8693-39d4-42a9-9062-c6b52c310745', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 6.5, '2026-08-21 19:38:27.38+00'),
	('702ff863-e6f6-4dfd-a41f-e2643a9f28f3', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 6.5, '2026-08-21 19:38:27.38+00'),
	('924ec0b2-2cc0-4320-811a-c581e46fe24e', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'b3d10346-5e6a-4d40-84fb-a66d50972f52', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 7.5, '2026-08-21 19:38:27.38+00'),
	('709a46f8-de74-4af4-b1dd-3bf1ab95844c', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '017649f7-3d20-4a79-9512-c177438f6790', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8, '2026-08-21 19:38:33.852+00'),
	('9d8ec1a9-0ae0-45dd-ac54-3fd7c88a8728', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '017649f7-3d20-4a79-9512-c177438f6790', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7.5, '2026-08-21 19:38:33.852+00'),
	('3f362470-b925-4e67-b3b1-ac327f281847', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '017649f7-3d20-4a79-9512-c177438f6790', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8, '2026-08-21 19:38:37.079+00'),
	('57e0944d-b31d-4dc8-90b4-60b88be9b6ff', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f08a596-c36d-4fec-9684-c11b87cd7547', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 7, '2026-08-21 19:38:43.366+00'),
	('abf2eeb6-bdf1-40ba-a3bf-d612ad89c47f', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f08a596-c36d-4fec-9684-c11b87cd7547', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 7.5, '2026-08-21 19:38:43.366+00'),
	('f40682be-8b29-49ac-8159-1d36e79691ab', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f08a596-c36d-4fec-9684-c11b87cd7547', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8.5, '2026-08-21 19:38:46.627+00'),
	('65e48bf2-9698-4641-8602-a344f6a1b5b4', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 8.5, '2026-08-21 19:38:54.609+00'),
	('a8f0573f-ad18-418a-a6f7-63d10f0d8ce7', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 6.5, '2026-08-21 19:38:54.609+00'),
	('4755f789-185e-475c-9c56-7189eec1d385', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'f5692ba1-272c-4275-97fe-8aee2b9f010d', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 6.5, '2026-08-21 19:38:54.609+00'),
	('1442ae3f-526e-4e52-85cf-f81adebd28d1', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '4a392f5c-55a0-4e24-8f12-23a49993e2de', '5fb86f5d-0cb9-44cd-b964-a82eca07b485', 7.5, '2026-08-21 19:39:03.658+00'),
	('8bb663dc-c07e-4c91-a9a4-23f7097f2dc5', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '4a392f5c-55a0-4e24-8f12-23a49993e2de', 'e722765b-7e22-4099-a0d3-5f5514d5a297', 8, '2026-08-21 19:39:03.658+00'),
	('2b73d6d7-f2bc-4495-ab67-9a4a561bba07', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '4a392f5c-55a0-4e24-8f12-23a49993e2de', '78542b2b-d2dc-4371-85cf-f7d6d209fbcb', 8, '2026-08-21 19:39:03.658+00'),
	('2c1684ad-c1f0-4d2a-860e-21dc575c7405', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '247e7d3f-2b9b-4a2d-afd6-0be48db6ff11', 'd5071420-340c-45a0-a783-512e96222e4b', 6.5, '2026-08-21 19:39:16.044+00'),
	('55e067f6-c205-49fe-a79a-62cb37f8fc4d', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '247e7d3f-2b9b-4a2d-afd6-0be48db6ff11', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 8, '2026-08-21 19:39:17.094+00'),
	('5856a677-a4bb-415c-b6e7-c457e587e702', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '247e7d3f-2b9b-4a2d-afd6-0be48db6ff11', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 7, '2026-08-21 19:39:18.389+00'),
	('27417075-02c7-47a5-b362-5f89a1f22ab0', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'd5071420-340c-45a0-a783-512e96222e4b', 7, '2026-08-21 19:39:21.876+00'),
	('483969ed-8df6-479b-8024-c6cd87004215', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 8, '2026-08-21 19:39:21.876+00'),
	('2e46f67d-6ab4-4b88-881f-f15f85cb7039', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 8, '2026-08-21 19:39:21.876+00'),
	('01407af5-880f-4a8e-b0ab-d96d3803ee54', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 9.5, '2026-08-21 19:39:24.169+00'),
	('4f63bd2e-0888-4266-9744-3aa978390a55', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 8.5, '2026-08-21 19:39:26.67+00'),
	('c288c9cb-23da-4223-9c21-b910e5ee1c4a', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'd5071420-340c-45a0-a783-512e96222e4b', 9.5, '2026-08-21 19:39:28.716+00'),
	('28118faf-0234-445d-8d6b-c9d8b3ded579', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'd5071420-340c-45a0-a783-512e96222e4b', 7, '2026-08-21 19:39:30.761+00'),
	('57157406-6348-4c96-a3f2-5302b4d3b3dc', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 7.5, '2026-08-21 19:39:34.898+00'),
	('4b8cb553-d53f-4fe0-93b8-1a75634f126f', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 6.5, '2026-08-21 19:39:34.898+00'),
	('b5aff492-c99d-42f6-b63b-454cf7104aaf', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f05613f-4325-4513-a39c-61af51816328', 'd5071420-340c-45a0-a783-512e96222e4b', 5.5, '2026-08-21 19:39:38.898+00'),
	('5db1e0ca-df42-47c0-98ff-147ee7d099e3', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f05613f-4325-4513-a39c-61af51816328', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 6.5, '2026-08-21 19:39:38.898+00'),
	('7b358dd3-452a-4e48-b4de-0189c5215c58', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '3f05613f-4325-4513-a39c-61af51816328', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 3.5, '2026-08-21 19:39:39.846+00'),
	('5e342a2b-8d40-4483-afb3-c24b12193be2', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'd5071420-340c-45a0-a783-512e96222e4b', 6.5, '2026-08-21 19:39:42.221+00'),
	('a3348eb5-7b94-402f-9918-f09d5967dcb0', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 7, '2026-08-21 19:39:44.036+00'),
	('11ac26b9-a080-4338-83c8-1d9df14b6c11', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 5.5, '2026-08-21 19:39:45.017+00'),
	('d700e78c-bb98-42e3-9c81-6e37c4faa2ca', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'd5071420-340c-45a0-a783-512e96222e4b', 4.5, '2026-08-21 19:39:47.962+00'),
	('42a533eb-6718-43e8-9a04-e7d8b4810920', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 5, '2026-08-21 19:39:47.962+00'),
	('2b713bd8-a5e4-416b-811f-aa6ae2d1e08a', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 4.5, '2026-08-21 19:39:48.929+00'),
	('0f6efb8c-0295-48f3-a175-38f0daa79a6f', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'd5071420-340c-45a0-a783-512e96222e4b', 8.5, '2026-08-21 19:40:57.156+00'),
	('164cc19f-43c0-48b1-ba0d-1d11b0612015', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 9, '2026-08-21 19:40:59.246+00'),
	('58a7fc13-790f-4e69-8ec7-743078bc0594', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'a0b71967-46ae-4092-8272-567aeb01fc85', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 8, '2026-08-21 19:41:01.012+00'),
	('c354e502-592b-4cab-9456-51dd2509ffd7', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'd5071420-340c-45a0-a783-512e96222e4b', 9.5, '2026-08-21 19:41:02.774+00'),
	('601996f5-f758-4433-8613-b70ad9dad321', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '48ead168-d127-4413-b1c9-17ca78b0b26d', '9fa5c309-c34d-484f-9854-15ad34121f46', 6.5, '2026-08-21 19:41:07.086+00'),
	('f5eeb7d6-45ff-4551-b4bc-ac70da522d66', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 3.5, '2026-08-21 19:41:07.317+00'),
	('4bd1cb2b-69c8-4309-9d73-83ab0b90e5dd', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '0fac449b-56f3-4cd3-a02a-e621e7332dc4', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 5.5, '2026-08-21 19:41:07.317+00'),
	('bc44d83c-dfca-4e7c-ae62-4ce10b168a6f', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '48ead168-d127-4413-b1c9-17ca78b0b26d', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 8, '2026-08-21 19:41:08.622+00'),
	('49a864f5-bb45-422f-8c25-39ecc4beeffd', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'b85bf0ec-3426-4ff6-8714-9c687c41f900', '9fa5c309-c34d-484f-9854-15ad34121f46', 6, '2026-08-21 19:41:11.417+00'),
	('21767761-20f1-46b2-b717-2b60d9f7816c', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'd5071420-340c-45a0-a783-512e96222e4b', 3, '2026-08-21 19:41:12.091+00'),
	('41a168b5-0e49-4b96-91d9-8cdf539bcf80', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 4.5, '2026-08-21 19:41:12.091+00'),
	('ba47221c-740d-4546-9bb6-7f3048b80419', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '683993bc-d93d-4c85-9ddb-5975c42e0c18', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 6, '2026-08-21 19:41:12.091+00'),
	('3836c05a-b2e8-4c41-ae00-6425e441e57e', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'b85bf0ec-3426-4ff6-8714-9c687c41f900', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 7.5, '2026-08-21 19:41:12.56+00'),
	('eb0703ff-a8ab-44a9-97c2-c4df6539b288', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'e1ea0875-3080-42d7-9252-1b81c56858a5', '9fa5c309-c34d-484f-9854-15ad34121f46', 9, '2026-08-21 19:41:15.048+00'),
	('d8a60135-90da-48fb-ad34-c62c26da9f49', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f05613f-4325-4513-a39c-61af51816328', 'd5071420-340c-45a0-a783-512e96222e4b', 2.5, '2026-08-21 19:41:17.214+00'),
	('278f8eba-ddf6-44d5-a32f-b0173e2a864e', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f05613f-4325-4513-a39c-61af51816328', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 4, '2026-08-21 19:41:17.214+00'),
	('d8f3425b-537c-4713-a706-aa54f32a9fdc', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '3f05613f-4325-4513-a39c-61af51816328', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 6.5, '2026-08-21 19:41:17.214+00'),
	('28d991c8-e42e-46f2-b369-0d94c950f2c3', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'e1ea0875-3080-42d7-9252-1b81c56858a5', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 7.5, '2026-08-21 19:41:17.564+00'),
	('53645cd8-21c3-41ec-9b74-dd2ccb4a01ee', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'd5071420-340c-45a0-a783-512e96222e4b', 3, '2026-08-21 19:41:19.928+00'),
	('5fcb6e22-e111-4c02-9e0c-69d50454043b', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 5, '2026-08-21 19:41:24.116+00'),
	('e10ed7fb-63a1-495d-85f6-0c404c9f33e1', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '80db6bc6-2a83-47d4-9b4a-14ccea725dbc', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 8, '2026-08-21 19:41:24.116+00'),
	('ad1a044d-aa5d-45d6-9776-b6295627f8b2', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '1799d8b8-3a43-48a9-9c4a-f1afa9b8be29', '9fa5c309-c34d-484f-9854-15ad34121f46', 7.5, '2026-08-21 19:41:25.274+00'),
	('8acf4cfb-cdbd-4ed1-9613-3319cada1048', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '1799d8b8-3a43-48a9-9c4a-f1afa9b8be29', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 8.5, '2026-08-21 19:41:26.645+00'),
	('62e3b0fe-1e15-45dc-9193-a202d78d4bfb', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'd5071420-340c-45a0-a783-512e96222e4b', 2, '2026-08-21 19:41:30.333+00'),
	('b1d426fc-0819-48dd-99bb-43f6948d79e8', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'ee2e5fc6-e3e5-4c17-921f-1080f25edeaa', 5, '2026-08-21 19:41:30.333+00'),
	('a573ad39-0078-42c6-9557-0f6e8998a57a', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'd8c9d046-1223-4573-a19a-8d0648eaa112', 'fd541560-8cb0-47a2-8785-c379fffe7c44', 7.5, '2026-08-21 19:41:30.333+00'),
	('22e9b952-e376-4fbd-a1e2-5eb5ff536c8c', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '0fb7a1ff-4c79-464d-8c99-5ae06981ed3d', '9fa5c309-c34d-484f-9854-15ad34121f46', 7.5, '2026-08-21 19:41:30.36+00'),
	('7ae89458-a65c-4ca5-81ef-c374966b89d7', '62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '0fb7a1ff-4c79-464d-8c99-5ae06981ed3d', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 6.5, '2026-08-21 19:41:31.525+00'),
	('7f236725-7e07-4ea7-b181-3f215112c577', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '48ead168-d127-4413-b1c9-17ca78b0b26d', '9fa5c309-c34d-484f-9854-15ad34121f46', 3.5, '2026-08-21 19:42:04.48+00'),
	('ad9e822c-67cc-487c-87eb-628b5ecba54a', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '48ead168-d127-4413-b1c9-17ca78b0b26d', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 3, '2026-08-21 19:42:04.48+00'),
	('405bd424-a92f-45a7-a024-0d28f5900c23', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'b85bf0ec-3426-4ff6-8714-9c687c41f900', '9fa5c309-c34d-484f-9854-15ad34121f46', 2.5, '2026-08-21 19:42:07.227+00'),
	('eebfdb58-b1df-4334-bd77-1b9c4b3d55bb', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'b85bf0ec-3426-4ff6-8714-9c687c41f900', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 2.5, '2026-08-21 19:42:07.227+00'),
	('b8d1cf3f-ea70-452b-a410-51c9237dbeea', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e1ea0875-3080-42d7-9252-1b81c56858a5', '9fa5c309-c34d-484f-9854-15ad34121f46', 2, '2026-08-21 19:42:09.8+00'),
	('6bf7b48b-896d-4c64-90e1-bffb2f0eef4d', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', 'e1ea0875-3080-42d7-9252-1b81c56858a5', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 2.5, '2026-08-21 19:42:09.8+00'),
	('bc8c1ddd-b93f-4135-add4-b38a44fdf536', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '1799d8b8-3a43-48a9-9c4a-f1afa9b8be29', '9fa5c309-c34d-484f-9854-15ad34121f46', 3, '2026-08-21 19:42:12.821+00'),
	('1a274954-4cdf-4efd-9ef5-45d013011fa8', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '1799d8b8-3a43-48a9-9c4a-f1afa9b8be29', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 5.5, '2026-08-21 19:42:12.821+00'),
	('459ae9c7-87e6-422f-a81f-0105b1e3e840', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '0fb7a1ff-4c79-464d-8c99-5ae06981ed3d', '9fa5c309-c34d-484f-9854-15ad34121f46', 1.5, '2026-08-21 19:42:15.369+00'),
	('9e67b8ab-2e52-495e-868e-4d5fa352e297', 'c275e289-2a76-4555-ba1d-eac3b9b20d38', '0fb7a1ff-4c79-464d-8c99-5ae06981ed3d', 'e74fcb31-31c6-46a0-a8fd-36b99b5a28c5', 3.5, '2026-08-21 19:42:15.369+00');


--
-- Data for Name: signin_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."signin_attempts" ("id", "identifier", "ok", "created_at") VALUES
	('ab9f03ad-dc9b-4e36-a56e-dc89b6a04a8e', '4f2ce873-e4e0-4dfb-bca2-9b3c0d83ca09', true, '2026-08-05 19:36:05.377713+00'),
	('e7cd6310-677e-4ad1-9173-f8d9730eb1fb', '6002ce78-2c9f-48fc-86db-98762c19309f', true, '2026-08-05 19:36:27.771608+00'),
	('5e61d8ad-4a64-43b9-a887-fef32b804e72', '7210d6cf-8397-48cc-89c2-57b6cf82433e', true, '2026-08-05 19:37:09.431321+00'),
	('9c8675f1-0ab3-4f73-bfeb-3c3458e2dc73', 'f9b1f8e2-f7e9-4094-9828-3588ca873ae0', true, '2026-08-05 20:07:56.352216+00'),
	('73b69fc5-ace9-484a-ad3e-6d82baf92c5c', '4897b373-9533-4520-8674-5d6439c35477', true, '2026-08-17 22:24:20.35718+00'),
	('8d6f2ada-178f-4e82-845d-a69faa4664f7', '4897b373-9533-4520-8674-5d6439c35477', true, '2026-08-17 22:47:23.29183+00'),
	('3abd5e48-fa95-4090-86e8-7496502a58ff', 'CA9EC9', true, '2026-08-18 16:13:18.805182+00'),
	('8795e85d-8c72-4847-b23e-f01cd987f662', '424055e4-543d-4291-8373-6a11a613bd1a', true, '2026-08-18 21:40:02.474145+00'),
	('8a3c84e7-bf3b-4f71-800c-45d65a124769', '02ADFA', true, '2026-08-18 21:50:07.387375+00'),
	('3275e294-31d2-437a-9c3c-caa85cc12430', '02ADFA', true, '2026-08-18 21:51:48.396443+00'),
	('7ec7a530-1ea4-42c9-904f-f402931c6796', 'T78PQQ', true, '2026-08-20 10:57:50.413972+00'),
	('599ba5b3-8cbb-4c45-8050-107577a94d18', 'CZCKNM', true, '2026-08-21 16:17:14.392094+00'),
	('981968c9-c23f-4866-8a16-c1b26019e042', 'H7KNP2', true, '2026-08-21 19:36:24.685332+00'),
	('fef73527-5834-4dcf-bb0c-404b68684f27', 'H7KNP2', true, '2026-08-21 19:37:00.605672+00');


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."submissions" ("judge_id", "round_id", "submitted_at") VALUES
	('f788edb3-1a4e-43d6-9afb-41933faac22e', 'e20a5afe-e7b0-4e19-be04-8e7b2964c08c', '2026-08-05 20:10:58.394386+00'),
	('f788edb3-1a4e-43d6-9afb-41933faac22e', '0a138b95-9642-48fd-8a6d-ed0810638b5a', '2026-08-05 20:13:22.810144+00'),
	('f788edb3-1a4e-43d6-9afb-41933faac22e', '44b24dc3-0cea-482b-a666-943701ffa25d', '2026-08-05 20:16:13.500551+00'),
	('c93848d3-becc-41d6-b763-afdb5b2a49ae', '3f2224d4-63a6-421b-b5e6-d6cd1c2cf0df', '2026-08-17 23:29:26.849999+00'),
	('c93848d3-becc-41d6-b763-afdb5b2a49ae', '6efcabad-bfce-42c7-b503-b4887880c474', '2026-08-18 16:19:31.596831+00'),
	('c93848d3-becc-41d6-b763-afdb5b2a49ae', '69490190-ffbd-4b86-b99a-f58b077e00e0', '2026-08-18 16:29:09.011934+00'),
	('684ab909-92c0-4d21-8241-6c4ac085574c', '4492eb99-9c90-4b1b-bac5-5dfc44556a48', '2026-08-20 10:59:31.902474+00'),
	('684ab909-92c0-4d21-8241-6c4ac085574c', '59e073c7-5bb6-4fc9-a963-716f140426f9', '2026-08-20 11:00:38.065981+00'),
	('684ab909-92c0-4d21-8241-6c4ac085574c', '2d915dd9-4476-473b-951a-e7308a01bc80', '2026-08-20 11:01:30.677812+00'),
	('40575c13-ad56-41a8-aa77-58dc77ee09ea', 'cafb8481-681a-44d1-bc71-f5ffeccdac6a', '2026-08-21 16:21:48.850415+00'),
	('40575c13-ad56-41a8-aa77-58dc77ee09ea', '9fec09c1-1849-4508-be55-e604dbf087c2', '2026-08-21 16:22:56.025801+00'),
	('40575c13-ad56-41a8-aa77-58dc77ee09ea', 'c3a87435-e70e-45fd-83e0-c75e0831dfcb', '2026-08-21 16:23:46.67185+00'),
	('62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '62677e14-1364-463d-bbf4-ffe90731a55b', '2026-08-21 19:38:38.610084+00'),
	('c275e289-2a76-4555-ba1d-eac3b9b20d38', '62677e14-1364-463d-bbf4-ffe90731a55b', '2026-08-21 19:39:40.082724+00'),
	('62b97ad1-4a28-4230-b88c-b86d0fe7cf97', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '2026-08-21 19:40:20.821889+00'),
	('c275e289-2a76-4555-ba1d-eac3b9b20d38', 'a49fc10c-0006-4f85-9319-de52b14d00f2', '2026-08-21 19:41:37.787683+00'),
	('62b97ad1-4a28-4230-b88c-b86d0fe7cf97', '8466353c-ad30-45bb-ace6-f8c06d73763d', '2026-08-21 19:41:41.733489+00'),
	('c275e289-2a76-4555-ba1d-eac3b9b20d38', '8466353c-ad30-45bb-ace6-f8c06d73763d', '2026-08-21 19:42:17.123281+00');


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

INSERT INTO "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status") VALUES
	('event-media', 'event-media', NULL, '2026-08-04 20:21:34.149281+00', '2026-08-04 20:21:34.149281+00', false, false, NULL, NULL, NULL, 'STANDARD', 'DISABLED');


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--



--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 49, true);


--
-- PostgreSQL database dump complete
--

-- \unrestrict 6fvXj6z3G27ZaXh9VNp6YpQwMiYrkMVtO3v4GXjkZCBQKhV788fsdRzfZArqXjd

RESET ALL;
